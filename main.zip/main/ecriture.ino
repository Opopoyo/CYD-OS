#include "ecriture.h"
#include "menu_core.h"
#include "text_engine.h"

// =====================================================
// CONFIG
// =====================================================

#define WR_TEXT_MAX 800

#define WR_TOP_H 30

#define WR_TEXT_X 6
#define WR_TEXT_Y 34
#define WR_TEXT_W 308
#define WR_TEXT_H 92

#define WR_KB_Y 130
#define WR_KEY_W 28
#define WR_KEY_H 21
#define WR_GAP 3

#define WR_ROW1_Y 130
#define WR_ROW2_Y 154
#define WR_ROW3_Y 178
#define WR_BOTTOM_Y 204

// =====================================================
// VARIABLES
// =====================================================

String wrText = "";
int wrCursor = 0;

bool wrMajuscule = false;
int wrMode = 0; // 0 lettres, 1 accents, 2 chiffres/symboles

unsigned long wrLastTouch = 0;

// Prototypes utiles
void wrDrawAll();
void wrDrawTextArea();

// =====================================================
// TOUCHES SANS TABLEAUX GLOBAUX
// =====================================================

const char* wrKeyLower1(int i) {
  switch (i) {
    case 0: return "a"; case 1: return "z"; case 2: return "e"; case 3: return "r"; case 4: return "t";
    case 5: return "y"; case 6: return "u"; case 7: return "i"; case 8: return "o"; case 9: return "p";
  }
  return "";
}

const char* wrKeyLower2(int i) {
  switch (i) {
    case 0: return "q"; case 1: return "s"; case 2: return "d"; case 3: return "f"; case 4: return "g";
    case 5: return "h"; case 6: return "j"; case 7: return "k"; case 8: return "l"; case 9: return "m";
  }
  return "";
}

const char* wrKeyLower3(int i) {
  switch (i) {
    case 0: return "w"; case 1: return "x"; case 2: return "c"; case 3: return "v"; case 4: return "b"; case 5: return "n";
  }
  return "";
}

const char* wrKeyUpper1(int i) {
  switch (i) {
    case 0: return "A"; case 1: return "Z"; case 2: return "E"; case 3: return "R"; case 4: return "T";
    case 5: return "Y"; case 6: return "U"; case 7: return "I"; case 8: return "O"; case 9: return "P";
  }
  return "";
}

const char* wrKeyUpper2(int i) {
  switch (i) {
    case 0: return "Q"; case 1: return "S"; case 2: return "D"; case 3: return "F"; case 4: return "G";
    case 5: return "H"; case 6: return "J"; case 7: return "K"; case 8: return "L"; case 9: return "M";
  }
  return "";
}

const char* wrKeyUpper3(int i) {
  switch (i) {
    case 0: return "W"; case 1: return "X"; case 2: return "C"; case 3: return "V"; case 4: return "B"; case 5: return "N";
  }
  return "";
}

const char* wrKeyAcc1(int i) {
  switch (i) {
    case 0: return "é"; case 1: return "è"; case 2: return "ê"; case 3: return "ë"; case 4: return "à";
    case 5: return "â"; case 6: return "ä"; case 7: return "ç"; case 8: return "ù"; case 9: return "û";
  }
  return "";
}

const char* wrKeyAcc2(int i) {
  switch (i) {
    case 0: return "ü"; case 1: return "î"; case 2: return "ï"; case 3: return "ô"; case 4: return "ö";
    case 5: return "œ"; case 6: return "æ"; case 7: return "É"; case 8: return "È"; case 9: return "Ç";
  }
  return "";
}

const char* wrKeyAcc3(int i) {
  switch (i) {
    case 0: return "À"; case 1: return "Â"; case 2: return "Ê"; case 3: return "Î"; case 4: return "Ô"; case 5: return "Œ";
  }
  return "";
}

const char* wrKeySym1(int i) {
  switch (i) {
    case 0: return "1"; case 1: return "2"; case 2: return "3"; case 3: return "4"; case 4: return "5";
    case 5: return "6"; case 6: return "7"; case 7: return "8"; case 8: return "9"; case 9: return "0";
  }
  return "";
}

const char* wrKeySym2(int i) {
  switch (i) {
    case 0: return "."; case 1: return ","; case 2: return "?"; case 3: return "!"; case 4: return ";";
    case 5: return ":"; case 6: return "-"; case 7: return "_"; case 8: return "/"; case 9: return "@";
  }
  return "";
}

const char* wrKeySym3(int i) {
  switch (i) {
    case 0: return "#"; case 1: return "&"; case 2: return "("; case 3: return ")"; case 4: return "+"; case 5: return "=";
  }
  return "";
}

const char* wrGetRow1(int i) {
  if (wrMode == 1) return wrKeyAcc1(i);
  if (wrMode == 2) return wrKeySym1(i);
  return wrMajuscule ? wrKeyUpper1(i) : wrKeyLower1(i);
}

const char* wrGetRow2(int i) {
  if (wrMode == 1) return wrKeyAcc2(i);
  if (wrMode == 2) return wrKeySym2(i);
  return wrMajuscule ? wrKeyUpper2(i) : wrKeyLower2(i);
}

const char* wrGetRow3(int i) {
  if (wrMode == 1) return wrKeyAcc3(i);
  if (wrMode == 2) return wrKeySym3(i);
  return wrMajuscule ? wrKeyUpper3(i) : wrKeyLower3(i);
}

// =====================================================
// UTF-8 CURSEUR
// =====================================================

int wrPrevCharIndex(String &s, int pos) {
  if (pos <= 0) return 0;

  pos--;

  while (pos > 0 && ((uint8_t)s[pos] & 0xC0) == 0x80) {
    pos--;
  }

  return pos;
}

int wrNextCharIndex(String &s, int pos) {
  if (pos >= s.length()) return s.length();

  pos++;

  while (pos < s.length() && ((uint8_t)s[pos] & 0xC0) == 0x80) {
    pos++;
  }

  return pos;
}

// =====================================================
// SAUVEGARDE
// =====================================================

String wrCleanFileName(String s) {
  s.trim();

  if (s.length() == 0) {
    s = "ecriture_" + String(millis());
  }

  s.replace("/", "_");
  s.replace("\\", "_");
  s.replace(":", "_");
  s.replace("*", "_");
  s.replace("?", "_");
  s.replace("\"", "_");
  s.replace("<", "_");
  s.replace(">", "_");
  s.replace("|", "_");
  s.replace("\n", "_");
  s.replace("\r", "_");

  if (s.length() > 24) {
    s = s.substring(0, 24);
  }

  return "/Archives/" + s + ".txt";
}

void wrSaveText() {
  String title = wrText;

  int cut = title.indexOf('\n');
  if (cut >= 0) title = title.substring(0, cut);

  title.trim();

  if (title.length() == 0) {
    title = "ecriture_" + String(millis());
  }

  if (!startSD()) {
    stopSDStartTouch();

    tft.fillScreen(TFT_BLACK);
    drawBoldText("Erreur SD", 160, 120, TFT_RED, TFT_BLACK, MC_DATUM, 2);
    delay(700);

    wrDrawAll();
    return;
  }

  SD.mkdir("/Archives");

  String path = wrCleanFileName(title);

  if (SD.exists(path)) SD.remove(path);

  File f = SD.open(path, FILE_WRITE);

  if (f) {
    f.println(title);
    f.println("-----");
    f.print(wrText);
    f.close();
  }

  stopSDStartTouch();

  tft.fillScreen(TFT_BLACK);
  drawBoldText("Texte sauvegarde", 160, 105, TFT_GREEN, TFT_BLACK, MC_DATUM, 2);
  drawBoldText(title, 160, 135, TFT_WHITE, TFT_BLACK, MC_DATUM, 2);

  delay(800);
  wrDrawAll();
}

// =====================================================
// DESSIN
// =====================================================

void wrDrawButton(int x, int y, int w, int h, const char* label, uint16_t bg = TFT_WHITE, uint16_t fg = TFT_BLACK) {
  tft.fillRoundRect(x, y, w, h, 4, bg);
  tft.drawRoundRect(x, y, w, h, 4, TFT_DARKGREY);

  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(fg, bg);

  uint8_t font = 1;
  if (strlen(label) <= 2) font = 2;

  tft.drawString(teToDisplay(String(label)), x + w / 2, y + h / 2, font);
}

void wrDrawPressedRect(int x, int y, int w, int h) {
  tft.drawRoundRect(x - 1, y - 1, w + 2, h + 2, 5, TFT_GREEN);
}

void wrDrawTopBar() {
  tft.fillRect(0, 0, 320, WR_TOP_H, TFT_BLACK);

  tft.fillTriangle(10, 15, 28, 6, 28, 24, TFT_WHITE);
  tft.fillTriangle(75, 15, 88, 7, 88, 23, TFT_WHITE);
  tft.fillTriangle(142, 15, 129, 7, 129, 23, TFT_WHITE);

  tft.fillRoundRect(205, 4, 105, 22, 5, TFT_WHITE);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(TFT_BLACK, TFT_WHITE);
  tft.drawString("SAUVER", 257, 15, 2);
}

String wrVisibleText() {
  if (wrText.length() <= 360) return wrText;

  int start = wrText.length() - 360;

  while (start < wrText.length() && ((uint8_t)wrText[start] & 0xC0) == 0x80) {
    start++;
  }

  return wrText.substring(start);
}

void wrDrawTextArea() {
  tft.fillRect(0, WR_TOP_H, 320, 98, TFT_BLACK);

  tft.fillRoundRect(WR_TEXT_X, WR_TEXT_Y, WR_TEXT_W, WR_TEXT_H, 6, TFT_WHITE);
  tft.drawRoundRect(WR_TEXT_X, WR_TEXT_Y, WR_TEXT_W, WR_TEXT_H, 6, TFT_DARKGREY);

  tft.setTextDatum(TL_DATUM);
  tft.setTextColor(TFT_BLACK, TFT_WHITE);

  int x = WR_TEXT_X + 6;
  int y = WR_TEXT_Y + 6;
  int maxW = WR_TEXT_W - 12;
  int maxY = WR_TEXT_Y + WR_TEXT_H - 16;
  int lineH = 14;

  String displayText = wrVisibleText();

  String word = "";
  String line = "";

  for (int i = 0; i <= displayText.length(); i++) {
    char c = (i < displayText.length()) ? displayText[i] : ' ';

    bool sep = (c == ' ' || c == '\n' || i >= displayText.length());

    if (!sep) {
      word += c;
      continue;
    }

    String test = line;

    if (test.length() > 0) test += " ";
    test += word;

    if (tft.textWidth(teToDisplay(test), 1) > maxW && line.length() > 0) {
      tft.drawString(teToDisplay(line), x, y, 1);

      y += lineH;
      if (y > maxY) return;

      line = word;
    } else {
      line = test;
    }

    if (c == '\n') {
      tft.drawString(teToDisplay(line), x, y, 1);

      y += lineH;
      if (y > maxY) return;

      line = "";
    }

    word = "";
  }

  if (line.length() > 0 && y <= maxY) {
    tft.drawString(teToDisplay(line), x, y, 1);
  }

  tft.drawFastVLine(WR_TEXT_X + WR_TEXT_W - 12, WR_TEXT_Y + WR_TEXT_H - 18, 12, TFT_RED);
}

void wrDrawKeyboard() {
  tft.fillRect(0, WR_KB_Y - 1, 320, 111, TFT_BLACK);

  for (int i = 0; i < 10; i++) {
    wrDrawButton(5 + i * (WR_KEY_W + WR_GAP), WR_ROW1_Y, WR_KEY_W, WR_KEY_H, wrGetRow1(i));
  }

  for (int i = 0; i < 10; i++) {
    wrDrawButton(10 + i * (WR_KEY_W + WR_GAP), WR_ROW2_Y, WR_KEY_W, WR_KEY_H, wrGetRow2(i));
  }

  if (wrMode == 0) {
    wrDrawButton(5, WR_ROW3_Y, 40, WR_KEY_H, wrMajuscule ? "min" : "MAJ", TFT_YELLOW);
  } else {
    wrDrawButton(5, WR_ROW3_Y, 40, WR_KEY_H, "ABC", TFT_CYAN);
  }

  for (int i = 0; i < 6; i++) {
    wrDrawButton(50 + i * (WR_KEY_W + WR_GAP), WR_ROW3_Y, WR_KEY_W, WR_KEY_H, wrGetRow3(i));
  }

  wrDrawButton(246, WR_ROW3_Y, 68, WR_KEY_H, "<-", TFT_RED, TFT_WHITE);

  wrDrawButton(5,   WR_BOTTOM_Y, 48, 28, "123", TFT_CYAN);
  wrDrawButton(58,  WR_BOTTOM_Y, 48, 28, "ACC", TFT_ORANGE);
  wrDrawButton(111, WR_BOTTOM_Y, 105, 28, "ESPACE", TFT_WHITE);
  wrDrawButton(221, WR_BOTTOM_Y, 38, 28, ".", TFT_WHITE);
  wrDrawButton(264, WR_BOTTOM_Y, 50, 28, "ENT", TFT_GREEN);
}

void wrDrawAll() {
  tft.fillScreen(TFT_BLACK);
  wrDrawTopBar();
  wrDrawTextArea();
  wrDrawKeyboard();
}

// =====================================================
// ACTIONS TEXTE
// =====================================================

void wrInsert(String s) {
  if (wrText.length() + s.length() > WR_TEXT_MAX) return;

  wrText = wrText.substring(0, wrCursor) + s + wrText.substring(wrCursor);
  wrCursor += s.length();

  if (wrMode == 0 && wrMajuscule) {
    wrMajuscule = false;
  }

  wrDrawAll();
}

void wrBackspace() {
  if (wrCursor <= 0 || wrText.length() == 0) return;

  int prev = wrPrevCharIndex(wrText, wrCursor);

  wrText.remove(prev, wrCursor - prev);
  wrCursor = prev;

  wrDrawAll();
}

void wrMoveLeft() {
  wrCursor = wrPrevCharIndex(wrText, wrCursor);
  wrDrawTextArea();
}

void wrMoveRight() {
  wrCursor = wrNextCharIndex(wrText, wrCursor);
  wrDrawTextArea();
}

// =====================================================
// TACTILE
// =====================================================

bool wrInRect(int x, int y, int rx, int ry, int rw, int rh) {
  return x >= rx && x <= rx + rw && y >= ry && y <= ry + rh;
}

void wrHandleTopBar(int x, int y) {
  if (wrInRect(x, y, 0, 0, 42, WR_TOP_H)) {
    drawSubMenu(currentMenu);
    return;
  }

  if (wrInRect(x, y, 55, 0, 55, WR_TOP_H)) {
    wrMoveLeft();
    return;
  }

  if (wrInRect(x, y, 115, 0, 55, WR_TOP_H)) {
    wrMoveRight();
    return;
  }

  if (wrInRect(x, y, 205, 0, 110, WR_TOP_H)) {
    wrSaveText();
    return;
  }
}

void wrHandleKeyboard(int x, int y) {
  if (y >= WR_ROW1_Y && y <= WR_ROW1_Y + WR_KEY_H) {
    for (int i = 0; i < 10; i++) {
      int kx = 5 + i * (WR_KEY_W + WR_GAP);

      if (wrInRect(x, y, kx, WR_ROW1_Y, WR_KEY_W, WR_KEY_H)) {
        wrDrawPressedRect(kx, WR_ROW1_Y, WR_KEY_W, WR_KEY_H);
        delay(25);
        wrInsert(String(wrGetRow1(i)));
        return;
      }
    }
  }

  if (y >= WR_ROW2_Y && y <= WR_ROW2_Y + WR_KEY_H) {
    for (int i = 0; i < 10; i++) {
      int kx = 10 + i * (WR_KEY_W + WR_GAP);

      if (wrInRect(x, y, kx, WR_ROW2_Y, WR_KEY_W, WR_KEY_H)) {
        wrDrawPressedRect(kx, WR_ROW2_Y, WR_KEY_W, WR_KEY_H);
        delay(25);
        wrInsert(String(wrGetRow2(i)));
        return;
      }
    }
  }

  if (wrInRect(x, y, 5, WR_ROW3_Y, 40, WR_KEY_H)) {
    wrDrawPressedRect(5, WR_ROW3_Y, 40, WR_KEY_H);
    delay(25);

    if (wrMode == 0) wrMajuscule = !wrMajuscule;
    else wrMode = 0;

    wrDrawAll();
    return;
  }

  if (y >= WR_ROW3_Y && y <= WR_ROW3_Y + WR_KEY_H) {
    for (int i = 0; i < 6; i++) {
      int kx = 50 + i * (WR_KEY_W + WR_GAP);

      if (wrInRect(x, y, kx, WR_ROW3_Y, WR_KEY_W, WR_KEY_H)) {
        wrDrawPressedRect(kx, WR_ROW3_Y, WR_KEY_W, WR_KEY_H);
        delay(25);
        wrInsert(String(wrGetRow3(i)));
        return;
      }
    }
  }

  if (wrInRect(x, y, 246, WR_ROW3_Y, 68, WR_KEY_H)) {
    wrDrawPressedRect(246, WR_ROW3_Y, 68, WR_KEY_H);
    delay(25);
    wrBackspace();
    return;
  }

  if (wrInRect(x, y, 5, WR_BOTTOM_Y, 48, 28)) {
    wrMode = 2;
    wrDrawAll();
    return;
  }

  if (wrInRect(x, y, 58, WR_BOTTOM_Y, 48, 28)) {
    wrMode = 1;
    wrDrawAll();
    return;
  }

  if (wrInRect(x, y, 111, WR_BOTTOM_Y, 105, 28)) {
    wrInsert(" ");
    return;
  }

  if (wrInRect(x, y, 221, WR_BOTTOM_Y, 38, 28)) {
    wrInsert(".");
    return;
  }

  if (wrInRect(x, y, 264, WR_BOTTOM_Y, 50, 28)) {
    wrInsert("\n");
    return;
  }
}

// =====================================================
// LANCEMENT / UPDATE
// =====================================================

void launchWriting() {
  appMode = MODE_WRITING;

  wrText = "";
  wrCursor = 0;
  wrMajuscule = false;
  wrMode = 0;
  wrLastTouch = 0;

  stopSDStartTouch();
  wrDrawAll();

  Serial.println("ECRITURE PRETE");
}

void updateWriting() {
  int x, y;

  if (!getTouch(x, y)) return;
  if (millis() - wrLastTouch < 130) return;

  wrLastTouch = millis();

  if (y < WR_TOP_H) {
    wrHandleTopBar(x, y);
  } else {
    wrHandleKeyboard(x, y);
  }

  while (ts.touched()) delay(5);
  delay(35);
}