#ifndef BESTIAIRE_H
#define BESTIAIRE_H

void launchBestiaire();
void updateBestiaire();

#endif