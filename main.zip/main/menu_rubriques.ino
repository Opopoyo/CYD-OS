// =====================================================
// RUBRIQUES / APPLICATIONS
// =====================================================

const char* menuNames[] = {
  "Livre",
  "Jeu",
  "Image",
  "Musique",
  "Texte",
  "Outil"
};

const int menuCount = sizeof(menuNames) / sizeof(menuNames[0]);

const char* appsLivre[] = {
  "R magique",
  "Encyclopedie",
  "Metal Urgen",
  "Fonts",
  "Livre2",
  "Livre3",
  "Biblio",
  "Bestiaire",
  "Actu"
};

const char* appsJeu[] = {
  "Chat",
  "Pong",
  "Dame",
  "Casse Brique",
  "Snake",
  "Tetris",
  "Pac-Man"
};

const char* appsImage[] = {
  "Galerie",
  "Peinture",
  "Pixel-Art"
};

const char* appsMusique[] = {
  "Instrument",
  "Disc",
  "Radio",
  "Sampler",
  "Compo",
  "Zic3"
};

const char* appsTexte[] = {
  "Clavier",
  "Ecriture",
  "Archive"
};

const char* appsOutil[] = {
  "Wifi",
  "Horloge",
  "Idee",
  "Carte SD",
  "Meteo",
  "Video",
  "SDWeb"
};


int getAppCount(int menuIndex) {
  switch (menuIndex) {
    case 0: return sizeof(appsLivre) / sizeof(appsLivre[0]);
    case 1: return sizeof(appsJeu) / sizeof(appsJeu[0]);
    case 2: return sizeof(appsImage) / sizeof(appsImage[0]);
    case 3: return sizeof(appsMusique) / sizeof(appsMusique[0]);
    case 4: return sizeof(appsTexte) / sizeof(appsTexte[0]);
    case 5: return sizeof(appsOutil) / sizeof(appsOutil[0]);
  }

  return 0;
}

String getAppName(int menuIndex, int appIndex) {
  switch (menuIndex) {
    case 0: return String(appsLivre[appIndex]);
    case 1: return String(appsJeu[appIndex]);
    case 2: return String(appsImage[appIndex]);
    case 3: return String(appsMusique[appIndex]);
    case 4: return String(appsTexte[appIndex]);
    case 5: return String(appsOutil[appIndex]);
  }

  return "";
}