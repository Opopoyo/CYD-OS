#include "menu_core.h"

#include "audio_system.h"
#include "audio_wav_player.h"
#include "loader.h"
#include "text_engine.h"

#include "clavier.h"
#include "ecriture.h"
#include "archive.h"
#include "galerie.h"
#include "peinture.h"
#include "liv_rmagic.h"
#include "jeu_chat.h"
#include "jeu_pong.h"
#include "wifi_app.h"
#include "horloge_app.h"
#include "instrument.h"
#include "disc.h"
#include "idee.h"
#include "dame.h"
#include "pixel_art.h"
#include "casse_brique.h"
#include "snake.h"
#include "carte_sd.h"
#include "tetris.h"
#include "sampler.h"
#include "compo.h"
#include "meteo.h"
#include "radio.h"
#include "encyclopedie.h"
#include "liv_metal_hurlant.h"
#include "fonts.h"
#include "sd_web.h"
#include "biblio.h"
#include "pacman.h"
#include "bestiaire.h"
#include "actu.h"

TFT_eSPI tft = TFT_eSPI();

SPIClass touchscreenSPI = SPIClass(VSPI);
XPT2046_Touchscreen ts(XPT2046_CS, XPT2046_IRQ);

SPIClass sdSPI = SPIClass(VSPI);

AppMode appMode = MODE_MENU;

void setup() {
  Serial.begin(115200);
  delay(300);

  // Son GPIO26 au repos dès le démarrage.
  audioSystemBegin();
  teBegin();

  pinMode(XPT2046_CS, OUTPUT);
  pinMode(SD_CS, OUTPUT);

  digitalWrite(XPT2046_CS, HIGH);
  digitalWrite(SD_CS, HIGH);

  tft.init();
  tft.invertDisplay(false);
  tft.setRotation(1);
  tft.fillScreen(TFT_BLACK);

  TJpgDec.setJpgScale(1);
  TJpgDec.setSwapBytes(true);
  TJpgDec.setCallback(tftOutput);

  // Image + son de démarrage + barre jaune.
  showLoaderStart();

  loaderProgress(45);

  // Connexion WiFi pendant que le loader reste affiché.
  wifiAutoConnect();

  loaderProgress(90);

  // On remet le tactile propre après la SD/loader.
  stopSDStartTouch();

  loaderProgress(100);
  delay(250);

  drawMainMenu();

  Serial.println("MENU CYD PRET");
}

void loop() {
  if (appMode == MODE_KEYBOARD) {
    updateKeyboard();
  }
  else if (appMode == MODE_WRITING) {
    updateWriting();
  }
  else if (appMode == MODE_ARCHIVE) {
    updateArchive();
  }
  else if (appMode == MODE_GALERIE) {
    updateGalerie();
  }
  else if (appMode == MODE_PAINT) {
    updatePeinture();
  }
  else if (appMode == MODE_RMAGIC) {
    updateRMagic();
  }
  else if (appMode == MODE_JEU_CHAT) {
    updateJeuChat();
  }
  else if (appMode == MODE_JEU_PONG) {
    updateJeuPong();
  }
  else if (appMode == MODE_WIFI) {
    updateWifiApp();
  }
  else if (appMode == MODE_HORLOGE) {
    updateHorlogeApp();
  }
  else if (appMode == MODE_INSTRUMENT) {
    updateInstrument();
  }
  else if (appMode == MODE_DISC) {
    updateDisc();
  }
  else if (appMode == MODE_IDEE) {
    updateIdee();
  }
  else if (appMode == MODE_DAME) {
    updateDame();
  }
  else if (appMode == MODE_PIXEL_ART) {
    updatePixelArt();
  }
  else if (appMode == MODE_CASSE_BRIQUE) {
    updateCasseBrique();
  }
  else if (appMode == MODE_SNAKE) {
    updateSnake();
  }
  else if (appMode == MODE_CARTE_SD) {
    updateCarteSD();
  }
  else if (appMode == MODE_TETRIS) {
    updateTetris();
  }
  else if (appMode == MODE_SAMPLER) {
    updateSampler();
  }
  else if (appMode == MODE_COMPO) {
    updateCompo();
  }
  else if (appMode == MODE_METEO) {
    updateMeteo();
  }
  else if (appMode == MODE_RADIO) {
    updateRadio();
  }
  else if (appMode == MODE_VIDEO) {
    updateVideo();
  }
  else if (appMode == MODE_ENCYCLOPEDIE) {
    updateEncyclopedie();
  }
  else if (appMode == MODE_METAL_HURLANT) {
    updateMetalHurlant();
  }
  else if (appMode == MODE_FONTS) {
    updateFonts();
  }
  else if (appMode == MODE_SD_WEB) {
    updateSdWeb();
  }
  else if (appMode == MODE_BIBLIO) {
    updateBiblio();
  }
  else if (appMode == MODE_PACMAN) {
    updatePacman();
  }
  else if (appMode == MODE_BESTIAIRE) {
    updateBestiaire();
  }
  else if (appMode == MODE_ACTU) {
    updateActu();
  }
  else {
    updateMenuTouch();
  }
}