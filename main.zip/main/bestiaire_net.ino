#include "bestiaire.h"
#include "menu_core.h"

#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <ArduinoJson.h>

#define BEST_MAX_RESULTS 4

String bestLabels[BEST_MAX_RESULTS];
String bestAbstracts[BEST_MAX_RESULTS];
String bestImages[BEST_MAX_RESULTS];
int bestCount = 0;

String bestUrlEncode(String s) {
  String out = "";
  const char *hex = "0123456789ABCDEF";

  for (int i = 0; i < s.length(); i++) {
    uint8_t c = (uint8_t)s[i];

    if ((c >= 'a' && c <= 'z') ||
        (c >= 'A' && c <= 'Z') ||
        (c >= '0' && c <= '9') ||
        c == '-' || c == '_' || c == '.' || c == '~') {
      out += (char)c;
    } else if (c == ' ') {
      out += "%20";
    } else {
      out += "%";
      out += hex[(c >> 4) & 0x0F];
      out += hex[c & 0x0F];
    }
  }

  return out;
}

String bestClean(String s) {
  s.replace("\n", " ");
  s.replace("\r", " ");
  s.replace("\t", " ");

  s.replace("Ã©", "é");
  s.replace("Ã¨", "è");
  s.replace("Ãª", "ê");
  s.replace("Ã ", "à");
  s.replace("Ã¢", "â");
  s.replace("Ã§", "ç");
  s.replace("Ã¹", "ù");
  s.replace("Ã»", "û");
  s.replace("Ã®", "î");
  s.replace("Ã´", "ô");
  s.replace("Å“", "œ");
  s.replace("Â", "");

  while (s.indexOf("  ") >= 0) s.replace("  ", " ");

  if (s.length() > 900) {
    s = s.substring(0, 900);
    s += "...";
  }

  return s;
}

bool bestIsJpg(String url) {
  String u = url;
  u.toLowerCase();
  return u.indexOf(".jpg") >= 0 || u.indexOf(".jpeg") >= 0;
}

bool bestSearchByName(String name) {
  bestCount = 0;

  if (WiFi.status() != WL_CONNECTED) return false;

  name.trim();
  if (name.length() == 0) return false;

  String url =
  "https://fr.wikipedia.org/w/api.php"
  "?action=query"
  "&format=json"
  "&generator=search"
  "&gsrlimit=4"
  "&gsrsearch=" + bestUrlEncode(name) +
  "&prop=extracts|pageimages"
  "&exintro=1"
  "&explaintext=1"
  "&pithumbsize=320"
  "&redirects=1";

  WiFiClientSecure client;
  client.setInsecure();

  HTTPClient http;
  if (!http.begin(client, url)) return false;

  http.addHeader("User-Agent", "CYD-Encyclopedie/1.0");
  http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);

  int code = http.GET();

  if (code != 200) {
    Serial.print("WIKI HTTP ");
    Serial.println(code);
    http.end();
    return false;
  }

  String payload = http.getString();
  http.end();

  DynamicJsonDocument doc(30000);
  DeserializationError err = deserializeJson(doc, payload);

  if (err) {
    Serial.print("JSON erreur : ");
    Serial.println(err.c_str());
    return false;
  }

  JsonObject pages = doc["query"]["pages"];

  for (JsonPair kv : pages) {
    if (bestCount >= BEST_MAX_RESULTS) break;

    JsonObject p = kv.value().as<JsonObject>();

    String title = p["title"].as<String>();
    String extract = p["extract"].as<String>();
    String img = "";

    if (p["thumbnail"]["source"]) {
      img = p["thumbnail"]["source"].as<String>();
    }

    if (title.length() == 0 || extract.length() < 20) continue;

    bestLabels[bestCount] = bestClean(title);
    bestAbstracts[bestCount] = bestClean(extract);
    bestImages[bestCount] = img;

    bestCount++;
  }

  return bestCount > 0;
}

bool bestDownloadImage(String url, String path) {
  if (url.length() == 0) return false;
  if (!bestIsJpg(url)) return false;
  if (WiFi.status() != WL_CONNECTED) return false;

  WiFiClientSecure client;
  client.setInsecure();

  HTTPClient http;
  if (!http.begin(client, url)) return false;

  http.addHeader("User-Agent", "CYD-Encyclopedie/1.0");
  http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);

  int code = http.GET();

  if (code != 200) {
    http.end();
    return false;
  }

  if (!startSD()) {
    http.end();
    stopSDStartTouch();
    return false;
  }

  if (!SD.exists("/bestiaire")) SD.mkdir("/bestiaire");
  if (!SD.exists("/bestiaire/cache")) SD.mkdir("/bestiaire/cache");

  if (SD.exists(path)) SD.remove(path);

  File f = SD.open(path, FILE_WRITE);

  if (!f) {
    http.end();
    stopSDStartTouch();
    return false;
  }

  WiFiClient *stream = http.getStreamPtr();
  uint8_t buffer[512];

  int total = 0;
  unsigned long lastData = millis();

  while (http.connected()) {
    int available = stream->available();

    if (available > 0) {
      int len = stream->readBytes(buffer, min(available, 512));
      f.write(buffer, len);
      total += len;
      lastData = millis();
    } else {
      delay(1);
    }

    if (!stream->connected() && !stream->available()) break;
    if (millis() - lastData > 8000) break;
    if (total > 130000) break;
  }

  f.close();
  http.end();
  stopSDStartTouch();

  return total > 1500;
}