#ifndef ACTU_H
#define ACTU_H

void launchActu();
void updateActu();

#endif