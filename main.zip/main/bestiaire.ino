#include "bestiaire.h"
#include "menu_core.h"
#include "wifi_app.h"
#include "text_engine.h"

#define BEST_BG "/systeme/Fparch4.jpg"
#define BEST_FONT "Roman18.vlw"
#define BEST_IMG_CACHE "/bestiaire/cache/animal.jpg"

#define BEST_MAX_RESULTS 4
#define BEST_MAX_ARTICLE_PAGES 10

#define BEST_READER_X 12
#define BEST_READER_Y 40
#define BEST_READER_W 296
#define BEST_READER_BOTTOM 204
#define BEST_READER_LINE_H 21

extern String bestLabels[];
extern String bestAbstracts[];
extern String bestImages[];
extern int bestCount;

bool bestSearchByName(String name);
bool bestDownloadImage(String url, String path);

enum BestState {
  BEST_HOME,
  BEST_KEYBOARD,
  BEST_LIST,
  BEST_READER,
  BEST_ERROR
};

BestState bestState = BEST_HOME;

String bestQuery = "";

int bestReaderPage = 0;
String bestArticleTitle = "";
String bestArticleText = "";
String bestArticleImage = "";
bool bestHasImagePage = false;

int bestTextPageCount = 0;
int bestTotalPages = 1;
int bestTextOffsets[BEST_MAX_ARTICLE_PAGES + 1];

unsigned long bestLastTouch = 0;

// =====================================================
// UI
// =====================================================

void bestText(String txt, int x, int y, uint8_t datum = MC_DATUM, uint8_t font = 2) {
  tft.setTextDatum(datum);
  tft.setTextColor(TFT_BLACK);
  tft.drawString(teToDisplay(txt), x, y, font);
}

void bestTinyText(String txt, int x, int y, uint8_t datum = MC_DATUM) {
  tft.setTextDatum(datum);
  tft.setTextColor(TFT_BLACK);
  tft.drawString(teToDisplay(txt), x, y, 1);
}

void bestDrawBg() {
  bool ok = false;

  if (startSD()) {
    if (SD.exists(BEST_BG)) {
      TJpgDec.setJpgScale(1);
      TJpgDec.drawSdJpg(0, 0, BEST_BG);
      ok = true;
    }

    stopSDStartTouch();
  }

  if (!ok) {
    tft.fillScreen(tft.color565(238, 228, 200));
  }
}

void bestHeader(String title) {
  tft.fillTriangle(10, 16, 31, 6, 31, 27, TFT_BLACK);

  if (title.length() > 24) title = title.substring(0, 24);

  bestText(title, 160, 16, MC_DATUM, 2);
}

void bestButton(int x, int y, int w, int h, String txt) {
  uint16_t bg = tft.color565(255, 248, 224);

  tft.fillRoundRect(x, y, w, h, 8, bg);
  tft.drawRoundRect(x, y, w, h, 8, TFT_BLACK);

  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(TFT_BLACK, bg);
  tft.drawString(teToDisplay(txt), x + w / 2, y + h / 2, 2);
}

void bestDrawLoading(String msg) {
  bestDrawBg();
  bestHeader("ENCYCLOPEDIE");

  bestText(msg, 160, 105);
  bestText("Veuillez patienter...", 160, 130);
}

void bestDrawError(String msg) {
  bestState = BEST_ERROR;

  bestDrawBg();
  bestHeader("ERREUR");

  bestText(msg, 160, 95);
  bestText("Essaie un autre mot.", 160, 122);
  bestButton(95, 160, 130, 28, "Retour");
}

// =====================================================
// TEXTE
// =====================================================

String bestCleanArticle(String s) {
  s.replace("\r", " ");
  s.replace("\n", " ");
  s.replace("\t", " ");

  s.replace("Ã©", "é");
  s.replace("Ã¨", "è");
  s.replace("Ãª", "ê");
  s.replace("Ã ", "à");
  s.replace("Ã¢", "â");
  s.replace("Ã§", "ç");
  s.replace("Ã¹", "ù");
  s.replace("Ã»", "û");
  s.replace("Ã®", "î");
  s.replace("Ã´", "ô");
  s.replace("Å“", "œ");
  s.replace("Â", "");

  while (s.indexOf("  ") >= 0) s.replace("  ", " ");

  s.trim();
  return s;
}

// =====================================================
// PAGINATION TEXTE
// =====================================================

int bestTextWidth(String s, bool loaded) {
  if (loaded) return tft.textWidth(s);
  return tft.textWidth(teToDisplay(s), 2);
}

int bestFindPageEnd(String text, int start, bool loaded) {
  int len = text.length();

  while (start < len && text[start] == ' ') start++;

  int pos = start;
  int cy = BEST_READER_Y;
  String line = "";

  while (pos < len) {
    while (pos < len && text[pos] == ' ') pos++;
    if (pos >= len) return len;

    int wordStart = pos;
    String word = "";

    while (pos < len && text[pos] != ' ') {
      word += text[pos];
      pos++;
    }

    if (word.length() == 0) continue;

    String test = line;
    if (test.length() > 0) test += " ";
    test += word;

    if (bestTextWidth(test, loaded) > BEST_READER_W && line.length() > 0) {
      cy += BEST_READER_LINE_H;

      if (cy > BEST_READER_BOTTOM) {
        return wordStart;
      }

      line = word;
    } else {
      line = test;
    }

    delay(0);
  }

  return len;
}

void bestBuildArticlePages() {
  bestTextPageCount = 0;
  bestTextOffsets[0] = 0;

  bool loaded = teLoadFont(BEST_FONT);

  int start = 0;
  int len = bestArticleText.length();

  while (start < len && bestTextPageCount < BEST_MAX_ARTICLE_PAGES) {
    int endPos = bestFindPageEnd(bestArticleText, start, loaded);

    if (endPos <= start) {
      endPos = min(start + 80, len);
    }

    bestTextPageCount++;
    bestTextOffsets[bestTextPageCount] = endPos;
    start = endPos;

    delay(0);
  }

  if (loaded) teUnloadFont();

  if (bestTextPageCount < 1) bestTextPageCount = 1;

  bestTotalPages = bestTextPageCount + (bestHasImagePage ? 1 : 0);
  if (bestTotalPages < 1) bestTotalPages = 1;
}

String bestGetTextPage(int textPageIndex) {
  if (textPageIndex < 0) textPageIndex = 0;
  if (textPageIndex >= bestTextPageCount) textPageIndex = bestTextPageCount - 1;

  int start = bestTextOffsets[textPageIndex];
  int endPos = bestTextOffsets[textPageIndex + 1];

  if (endPos <= start) return "";

  String s = bestArticleText.substring(start, endPos);
  s.trim();
  return s;
}

// =====================================================
// LISEUSE
// =====================================================

void bestDrawPageNumber() {
  bestTinyText(
    String(bestReaderPage + 1) + "/" + String(bestTotalPages),
    286,
    18,
    MC_DATUM
  );
}

void bestDrawBottomArrows() {
  int y = 224;

  if (bestReaderPage > 0) {
    tft.fillTriangle(265, y, 274, y - 6, 274, y + 6, TFT_BLACK);
  }

  if (bestReaderPage < bestTotalPages - 1) {
    tft.fillTriangle(311, y, 302, y - 6, 302, y + 6, TFT_BLACK);
  }
}

void bestDrawWrappedRoman(String s, int x, int y, int maxW, int maxY, int lineH) {
  bool loaded = teLoadFont(BEST_FONT);

  tft.setTextDatum(TL_DATUM);
  tft.setTextColor(TFT_BLACK);

  String word = "";
  String line = "";
  int cy = y;

  for (int i = 0; i <= s.length(); i++) {
    char c = (i < s.length()) ? s[i] : ' ';

    if (c == ' ') {
      String test = line;
      if (test.length() > 0) test += " ";
      test += word;

      int tw = loaded ? tft.textWidth(test) : tft.textWidth(teToDisplay(test), 2);

      if (tw > maxW && line.length() > 0) {
        if (loaded) tft.drawString(line, x, cy);
        else tft.drawString(teToDisplay(line), x, cy, 2);

        cy += lineH;
        if (cy > maxY) break;

        line = word;
      } else {
        line = test;
      }

      word = "";
    } else {
      word += c;
    }
  }

  if (line.length() > 0 && cy <= maxY) {
    if (loaded) tft.drawString(line, x, cy);
    else tft.drawString(teToDisplay(line), x, cy, 2);
  }

  if (loaded) teUnloadFont();
  stopSDStartTouch();
}

void bestDrawImagePage() {
  if (bestArticleImage.length() == 0) {
    bestText("Image indisponible", 160, 112);
    return;
  }

  bestTinyText("Image", 160, 42);

  bool ok = bestDownloadImage(bestArticleImage, BEST_IMG_CACHE);

  if (!ok) {
    bestText("Image indisponible", 160, 112);
    return;
  }

  if (startSD()) {
    if (SD.exists(BEST_IMG_CACHE)) {
      // Image centrée et réduite pour être visible entière.
      TJpgDec.setJpgScale(2);

      int iw = 140;
      int ih = 120;

      int ix = (320 - iw) / 2;
      int iy = (240 - ih) / 2;

      TJpgDec.drawSdJpg(ix, iy, BEST_IMG_CACHE);
      TJpgDec.setJpgScale(1);
    }

    stopSDStartTouch();
  }
}

void bestDrawReader() {
  bestState = BEST_READER;

  bestDrawBg();
  bestHeader(bestArticleTitle);
  bestDrawPageNumber();

  if (bestHasImagePage && bestReaderPage == 0) {
    bestDrawImagePage();
  } else {
    int textIndex = bestReaderPage - (bestHasImagePage ? 1 : 0);

    bestDrawWrappedRoman(
      bestGetTextPage(textIndex),
      BEST_READER_X,
      BEST_READER_Y,
      BEST_READER_W,
      BEST_READER_BOTTOM,
      BEST_READER_LINE_H
    );
  }

  bestDrawBottomArrows();
}

// =====================================================
// ECRANS
// =====================================================

void bestDrawHome() {
  bestState = BEST_HOME;

  bestDrawBg();
  bestHeader("ENCYCLOPEDIE");

  bestText("Recherche Wikipedia", 160, 58);

  String q = bestQuery;
  if (q.length() == 0) q = "Tapez votre recherche";
  if (q.length() > 32) q = q.substring(0, 32);

  tft.drawRoundRect(16, 88, 288, 34, 8, TFT_BLACK);
  bestText(q, 160, 105);

  bestButton(95, 145, 130, 34, "Rechercher");

  bestTinyText("Wikipedia FR", 160, 212);
}

void bestDrawList() {
  bestState = BEST_LIST;

  bestDrawBg();
  bestHeader("RESULTATS");

  if (bestCount <= 0) {
    bestText("Aucun resultat", 160, 100);
    return;
  }

  for (int i = 0; i < bestCount; i++) {
    int y = 48 + i * 34;

    tft.drawRoundRect(12, y, 296, 28, 6, TFT_BLACK);

    String label = bestLabels[i];
    if (label.length() > 32) label = label.substring(0, 32);

    bestText(String(i + 1) + ". " + label, 160, y + 14, MC_DATUM, 1);
  }
}

// =====================================================
// ACTIONS
// =====================================================

void bestDoSearch() {
  if (WiFi.status() != WL_CONNECTED) {
    launchWifiApp();
    return;
  }

  bestQuery.trim();

  if (bestQuery.length() == 0) {
    bestDrawError("Recherche vide");
    return;
  }

  bestDrawLoading("Recherche Wikipedia...");

  bool ok = bestSearchByName(bestQuery);

  if (!ok) {
    bestDrawError("Aucun resultat");
    return;
  }

  bestDrawList();
}

void bestOpenArticle(int index) {
  if (index < 0 || index >= bestCount) return;

  bestArticleTitle = bestLabels[index];
  bestArticleText = bestCleanArticle(bestAbstracts[index]);
  bestArticleImage = bestImages[index];

  bestHasImagePage = bestArticleImage.length() > 0;
  bestReaderPage = 0;

  bestBuildArticlePages();
  bestDrawReader();
}

// =====================================================
// LANCEMENT / UPDATE
// =====================================================

void launchBestiaire() {
  appMode = MODE_BESTIAIRE;

  stopSDStartTouch();
  WiFi.setSleep(false);

  bestQuery = "";
  bestReaderPage = 0;

  bestDrawHome();

  Serial.println("ENCYCLOPEDIE PRETE");
}

void updateBestiaire() {
  if (bestState == BEST_KEYBOARD) {
    teKeyboardUpdate();

    if (teKeyboardDone) {
      bestQuery = teKeyboardValue;
      teKeyboardClose();
      bestDrawHome();
    }

    if (teKeyboardCancel) {
      teKeyboardClose();
      bestDrawHome();
    }

    return;
  }

  int x, y;

  if (!getTouch(x, y)) return;
  if (millis() - bestLastTouch < 180) return;

  bestLastTouch = millis();

  if (x < 45 && y < 36) {
    if (bestState == BEST_HOME) {
      stopSDStartTouch();
      drawSubMenu(currentMenu);
    } else if (bestState == BEST_LIST) {
      bestDrawHome();
    } else if (bestState == BEST_READER) {
      bestDrawList();
    } else {
      bestDrawHome();
    }

    while (ts.touched()) delay(5);
    delay(80);
    return;
  }

  if (bestState == BEST_HOME) {
    // Cliquer la barre ouvre le clavier.
    if (x >= 16 && x <= 304 && y >= 88 && y <= 122) {
      bestState = BEST_KEYBOARD;
      teKeyboardOpen("Recherche", bestQuery);
    }

    // Bouton rechercher.
    else if (x >= 95 && x <= 225 && y >= 145 && y <= 179) {
      bestDoSearch();
    }
  }

  else if (bestState == BEST_LIST) {
    for (int i = 0; i < bestCount; i++) {
      int by = 48 + i * 34;

      if (x >= 12 && x <= 308 && y >= by && y <= by + 28) {
        bestOpenArticle(i);
        break;
      }
    }
  }

  else if (bestState == BEST_READER) {
    if (x >= 256 && x <= 284 && y >= 210 && y <= 240) {
      bestReaderPage--;

      if (bestReaderPage < 0) bestReaderPage = 0;

      bestDrawReader();
    }

    else if (x >= 292 && x <= 320 && y >= 210 && y <= 240) {
      bestReaderPage++;

      if (bestReaderPage >= bestTotalPages) {
        bestReaderPage = bestTotalPages - 1;
      }

      bestDrawReader();
    }
  }

  else if (bestState == BEST_ERROR) {
    if (x >= 95 && x <= 225 && y >= 160 && y <= 188) {
      bestDrawHome();
    }
  }

  while (ts.touched()) delay(5);
  delay(80);
}