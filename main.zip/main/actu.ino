#include "actu.h"
#include "menu_core.h"
#include "wifi_app.h"
#include "text_engine.h"

#define ACTU_BG "/systeme/Fparch4.jpg"
#define ACTU_IMG_CACHE "/actu/cache/article.jpg"

#define ACTU_MAX_ITEMS 4
#define ACTU_MAX_PAGES 8

#define ACTU_READER_X 12
#define ACTU_READER_Y 40
#define ACTU_READER_W 296
#define ACTU_READER_BOTTOM 204
#define ACTU_LINE_H 18

extern String actuTitles[];
extern String actuDescs[];
extern String actuLinks[];
extern String actuImages[];
extern int actuCount;

bool actuFetchRss(int source, int rubrique);
bool actuDownloadImage(String url, String path);

enum ActuState {
  ACTU_HOME,
  ACTU_RUBRIQUES,
  ACTU_LIST,
  ACTU_READER,
  ACTU_ERROR
};

ActuState actuState = ACTU_HOME;

int actuSource = 0;
int actuRubrique = 0;

String actuReaderTitle = "";
String actuReaderText = "";
String actuReaderImage = "";

bool actuHasImagePage = false;
int actuReaderPage = 0;
int actuTextPageCount = 0;
int actuTotalPages = 1;
int actuOffsets[ACTU_MAX_PAGES + 1];

unsigned long actuLastTouch = 0;

// =====================================================
// UI
// =====================================================

void actuText(String txt, int x, int y, uint8_t datum = MC_DATUM, uint8_t font = 2) {
  tft.setTextDatum(datum);
  tft.setTextColor(TFT_BLACK);
  tft.drawString(teToDisplay(txt), x, y, font);
}

void actuTiny(String txt, int x, int y, uint8_t datum = MC_DATUM) {
  tft.setTextDatum(datum);
  tft.setTextColor(TFT_BLACK);
  tft.drawString(teToDisplay(txt), x, y, 1);
}

void actuBg() {
  bool ok = false;

  if (startSD()) {
    if (SD.exists(ACTU_BG)) {
      TJpgDec.setJpgScale(1);
      TJpgDec.drawSdJpg(0, 0, ACTU_BG);
      ok = true;
    }

    stopSDStartTouch();
  }

  if (!ok) {
    tft.fillScreen(tft.color565(238, 228, 200));
  }
}

void actuHeader(String title) {
  tft.fillTriangle(10, 16, 31, 6, 31, 27, TFT_BLACK);

  if (title.length() > 24) title = title.substring(0, 24);
  actuText(title, 160, 16, MC_DATUM, 2);
}

void actuButton(int x, int y, int w, int h, String label) {
  uint16_t bg = tft.color565(255, 248, 224);

  tft.fillRoundRect(x, y, w, h, 8, bg);
  tft.drawRoundRect(x, y, w, h, 8, TFT_BLACK);

  actuText(label, x + w / 2, y + h / 2, MC_DATUM, 2);
}

void actuLoading(String msg) {
  actuBg();
  actuHeader("ACTU");
  actuText(msg, 160, 105);
  actuText("Veuillez patienter...", 160, 130);
}

void actuError(String msg) {
  actuState = ACTU_ERROR;

  actuBg();
  actuHeader("ERREUR");
  actuText(msg, 160, 100);
  actuButton(95, 155, 130, 30, "Retour");
}

// =====================================================
// SOURCES / RUBRIQUES
// =====================================================

String actuSourceName(int s) {
  if (s == 0) return "Franceinfo";
  if (s == 1) return "Le Monde";
  if (s == 2) return "France 24";
  return "Source";
}

String actuRubName(int r) {
  if (r == 0) return "Grands titres";
  if (r == 1) return "France";
  if (r == 2) return "Monde";
  if (r == 3) return "Culture";
  if (r == 4) return "Sport";
  return "Rubrique";
}

// =====================================================
// PAGINATION TEXTE
// =====================================================

String actuCleanArticle(String s) {
  s.replace("\r", " ");
  s.replace("\n", " ");
  s.replace("\t", " ");

  while (s.indexOf("  ") >= 0) s.replace("  ", " ");

  s.trim();
  return s;
}

int actuFindPageEnd(String text, int start) {
  int len = text.length();

  while (start < len && text[start] == ' ') start++;

  int pos = start;
  int cy = ACTU_READER_Y;
  String line = "";

  while (pos < len) {
    while (pos < len && text[pos] == ' ') pos++;
    if (pos >= len) return len;

    int wordStart = pos;
    String word = "";

    while (pos < len && text[pos] != ' ') {
      word += text[pos];
      pos++;
    }

    String test = line;
    if (test.length() > 0) test += " ";
    test += word;

    if (tft.textWidth(teToDisplay(test), 2) > ACTU_READER_W && line.length() > 0) {
      cy += ACTU_LINE_H;

      if (cy > ACTU_READER_BOTTOM) {
        return wordStart;
      }

      line = word;
    } else {
      line = test;
    }

    delay(0);
  }

  return len;
}

void actuBuildPages() {
  actuTextPageCount = 0;
  actuOffsets[0] = 0;

  int start = 0;
  int len = actuReaderText.length();

  while (start < len && actuTextPageCount < ACTU_MAX_PAGES) {
    int endPos = actuFindPageEnd(actuReaderText, start);

    if (endPos <= start) {
      endPos = min(start + 80, len);
    }

    actuTextPageCount++;
    actuOffsets[actuTextPageCount] = endPos;
    start = endPos;
  }

  if (actuTextPageCount < 1) actuTextPageCount = 1;

  actuTotalPages = actuTextPageCount + (actuHasImagePage ? 1 : 0);
  if (actuTotalPages < 1) actuTotalPages = 1;
}

String actuGetPage(int pageIndex) {
  if (pageIndex < 0) pageIndex = 0;
  if (pageIndex >= actuTextPageCount) pageIndex = actuTextPageCount - 1;

  int a = actuOffsets[pageIndex];
  int b = actuOffsets[pageIndex + 1];

  if (b <= a) return "";

  String s = actuReaderText.substring(a, b);
  s.trim();
  return s;
}

void actuDrawWrapped(String s, int x, int y, int maxW, int maxY, int lineH) {
  tft.setTextDatum(TL_DATUM);
  tft.setTextColor(TFT_BLACK);

  String word = "";
  String line = "";
  int cy = y;

  for (int i = 0; i <= s.length(); i++) {
    char c = (i < s.length()) ? s[i] : ' ';

    if (c == ' ') {
      String test = line;
      if (test.length() > 0) test += " ";
      test += word;

      if (tft.textWidth(teToDisplay(test), 2) > maxW && line.length() > 0) {
        tft.drawString(teToDisplay(line), x, cy, 2);

        cy += lineH;
        if (cy > maxY) break;

        line = word;
      } else {
        line = test;
      }

      word = "";
    } else {
      word += c;
    }
  }

  if (line.length() > 0 && cy <= maxY) {
    tft.drawString(teToDisplay(line), x, cy, 2);
  }
}

// =====================================================
// LECTEUR MAGAZINE
// =====================================================

void actuPageNav() {
  actuTiny(String(actuReaderPage + 1) + "/" + String(actuTotalPages), 286, 18);

  int y = 224;

  if (actuReaderPage > 0) {
    tft.fillTriangle(265, y, 274, y - 6, 274, y + 6, TFT_BLACK);
  }

  if (actuReaderPage < actuTotalPages - 1) {
    tft.fillTriangle(311, y, 302, y - 6, 302, y + 6, TFT_BLACK);
  }
}

void actuDrawImagePage() {
  if (actuReaderImage.length() == 0) {
    actuText("Image indisponible", 160, 112);
    return;
  }

  bool ok = actuDownloadImage(actuReaderImage, ACTU_IMG_CACHE);

  if (!ok) {
    actuText("Image indisponible", 160, 112);
    return;
  }

  if (startSD()) {
    if (SD.exists(ACTU_IMG_CACHE)) {
      TJpgDec.setJpgScale(2);

      int ix = (320 - 120) / 2;
      int iy = (240 - 90) / 2;

      TJpgDec.drawSdJpg(ix, iy, ACTU_IMG_CACHE);
      TJpgDec.setJpgScale(1);
    }

    stopSDStartTouch();
  }
}

void actuDrawReader() {
  actuState = ACTU_READER;

  actuBg();
  actuHeader(actuReaderTitle);
  actuPageNav();

  if (actuHasImagePage && actuReaderPage == 0) {
    actuDrawImagePage();
  } else {
    int page = actuReaderPage - (actuHasImagePage ? 1 : 0);

    actuDrawWrapped(
      actuGetPage(page),
      ACTU_READER_X,
      ACTU_READER_Y,
      ACTU_READER_W,
      ACTU_READER_BOTTOM,
      ACTU_LINE_H
    );
  }

  actuPageNav();
}

// =====================================================
// ECRANS
// =====================================================

void actuDrawHome() {
  actuState = ACTU_HOME;

  actuBg();
  actuHeader("ACTU");

  actuText("Choisir une source", 160, 52);

  actuButton(35, 82, 250, 32, "Franceinfo");
  actuButton(35, 122, 250, 32, "Le Monde");
  actuButton(35, 162, 250, 32, "France 24");
}

void actuDrawRubriques() {
  actuState = ACTU_RUBRIQUES;

  actuBg();
  actuHeader(actuSourceName(actuSource));

  actuText("Choisir une rubrique", 160, 46);

  actuButton(22, 72, 132, 30, "Grands titres");
  actuButton(166, 72, 132, 30, "France");

  actuButton(22, 112, 132, 30, "Monde");
  actuButton(166, 112, 132, 30, "Culture");

  actuButton(94, 152, 132, 30, "Sport");
}

void actuLoadRubrique(int r) {
  if (WiFi.status() != WL_CONNECTED) {
    launchWifiApp();
    return;
  }

  actuRubrique = r;

  actuLoading("Chargement RSS...");

  bool ok = actuFetchRss(actuSource, actuRubrique);

  if (!ok) {
    actuError("Aucune actu trouvee");
    return;
  }

  actuDrawList();
}

void actuDrawList() {
  actuState = ACTU_LIST;

  actuBg();
  actuHeader(actuRubName(actuRubrique));

  if (actuCount <= 0) {
    actuText("Aucun article", 160, 100);
    return;
  }

  for (int i = 0; i < actuCount; i++) {
    int y = 44 + i * 42;

    tft.drawRoundRect(10, y, 300, 36, 7, TFT_BLACK);

    String title = actuTitles[i];
    if (title.length() > 48) title = title.substring(0, 48);

    actuTiny(String(i + 1) + ". " + title, 160, y + 18);
  }

  actuTiny(actuSourceName(actuSource), 160, 224);
}

void actuOpenArticle(int index) {
  if (index < 0 || index >= actuCount) return;

  actuReaderTitle = actuTitles[index];
  actuReaderImage = actuImages[index];

  actuReaderText = actuCleanArticle(actuDescs[index]);

  if (actuLinks[index].length() > 0) {
    actuReaderText += " Source : ";
    actuReaderText += actuLinks[index];
  }

  actuHasImagePage = actuReaderImage.length() > 0;
  actuReaderPage = 0;

  actuBuildPages();
  actuDrawReader();
}

// =====================================================
// LANCEMENT / UPDATE
// =====================================================

void launchActu() {
  appMode = MODE_ACTU;

  stopSDStartTouch();
  WiFi.setSleep(false);

  actuSource = 0;
  actuRubrique = 0;
  actuReaderPage = 0;

  actuDrawHome();

  Serial.println("ACTU PRETE");
}

void updateActu() {
  int x, y;

  if (!getTouch(x, y)) return;
  if (millis() - actuLastTouch < 180) return;

  actuLastTouch = millis();

  if (x < 45 && y < 36) {
    if (actuState == ACTU_HOME) {
      drawSubMenu(currentMenu);
    } else if (actuState == ACTU_RUBRIQUES) {
      actuDrawHome();
    } else if (actuState == ACTU_LIST) {
      actuDrawRubriques();
    } else if (actuState == ACTU_READER) {
      actuDrawList();
    } else {
      actuDrawHome();
    }

    while (ts.touched()) delay(5);
    delay(60);
    return;
  }

  if (actuState == ACTU_HOME) {
    if (x >= 35 && x <= 285 && y >= 82 && y <= 114) {
      actuSource = 0;
      actuDrawRubriques();
    }

    else if (x >= 35 && x <= 285 && y >= 122 && y <= 154) {
      actuSource = 1;
      actuDrawRubriques();
    }

    else if (x >= 35 && x <= 285 && y >= 162 && y <= 194) {
      actuSource = 2;
      actuDrawRubriques();
    }
  }

  else if (actuState == ACTU_RUBRIQUES) {
    if (x >= 22 && x <= 154 && y >= 72 && y <= 102) actuLoadRubrique(0);
    else if (x >= 166 && x <= 298 && y >= 72 && y <= 102) actuLoadRubrique(1);
    else if (x >= 22 && x <= 154 && y >= 112 && y <= 142) actuLoadRubrique(2);
    else if (x >= 166 && x <= 298 && y >= 112 && y <= 142) actuLoadRubrique(3);
    else if (x >= 94 && x <= 226 && y >= 152 && y <= 182) actuLoadRubrique(4);
  }

  else if (actuState == ACTU_LIST) {
    for (int i = 0; i < actuCount; i++) {
      int by = 44 + i * 42;

      if (x >= 10 && x <= 310 && y >= by && y <= by + 36) {
        actuOpenArticle(i);
        break;
      }
    }
  }

  else if (actuState == ACTU_READER) {
    if (x >= 256 && x <= 284 && y >= 210 && y <= 240) {
      actuReaderPage--;
      if (actuReaderPage < 0) actuReaderPage = 0;
      actuDrawReader();
    }

    else if (x >= 292 && x <= 320 && y >= 210 && y <= 240) {
      actuReaderPage++;
      if (actuReaderPage >= actuTotalPages) actuReaderPage = actuTotalPages - 1;
      actuDrawReader();
    }
  }

  else if (actuState == ACTU_ERROR) {
    if (x >= 95 && x <= 225 && y >= 155 && y <= 185) {
      actuDrawRubriques();
    }
  }

  while (ts.touched()) delay(5);
  delay(60);
}