#ifndef PACMAN_H
#define PACMAN_H

#include <Arduino.h>
#include <TFT_eSPI.h>

enum PacDir {
  PAC_STOP,
  PAC_UP,
  PAC_DOWN,
  PAC_LEFT,
  PAC_RIGHT
};

struct Ghost {
  int col;
  int row;
  PacDir dir;
  uint16_t color;
};

void launchPacman();
void updatePacman();

#endif