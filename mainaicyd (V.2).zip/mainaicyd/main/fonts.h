#ifndef FONTS_H
#define FONTS_H

void launchFonts();
void updateFonts();

#endif