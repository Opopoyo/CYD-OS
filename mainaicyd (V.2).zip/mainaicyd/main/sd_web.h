#ifndef SD_WEB_H
#define SD_WEB_H

void launchSdWeb();
void updateSdWeb();

#endif