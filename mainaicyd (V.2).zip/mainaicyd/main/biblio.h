#ifndef BIBLIO_H
#define BIBLIO_H

void launchBiblio();
void updateBiblio();

#endif