#include "fonts.h"
#include "menu_core.h"
#include "text_engine.h"

#define FONT_COUNT 167
#define FONTS_PER_PAGE 5
#define FONT_BG_IMAGE "/systeme/Fparch4.jpg"

const char* fontList[FONT_COUNT] = {
  "Papernotes.vlw","GothamB14.vlw","GothamB16.vlw","GothamB18.vlw",
  "GothamB20.vlw","GothamB22.vlw","GothamB24.vlw","GothamB26.vlw",
  "Gotham26.vlw","Gotham24.vlw","Gotham22.vlw","Gotham20 (1).vlw",
  "Gotham20.vlw","Gotham18.vlw","Gotham16.vlw","Gotham14.vlw",
  "Gotham12.vlw","Modum14.vlw","Modum12.vlw","Pixelmania10.vlw",
  "Pixelmania12.vlw","Pixelmania14.vlw","Roman14.vlw","Roman18.vlw",
  "Roman22.vlw","Roman24.vlw","Ananda26.vlw","FreeSans.vlw",
  "_Comic10.vlw","_Comic12.vlw","_Comic14.vlw","_Comic16.vlw",
  "_Comic18.vlw","_Comic20.vlw","AristaLight12.vlw","AristaLight14.vlw",
  "AristaLight16.vlw","AristaLight18.vlw","Papernotes20.vlw",
  "Papernotes18.vlw","Papernotes16.vlw","Papernotes14.vlw",
  "Papernotes12.vlw","Plank20.vlw","Plank18.vlw","Plank16.vlw",
  "Plank14.vlw","Dune8.vlw","Dune10.vlw","Dune12.vlw",
  "Dune14.vlw","Dune16.vlw","Dune18.vlw","Ananda22.vlw",
  "GothamB12.vlw","AristaLight20.vlw","AristaLight22.vlw",
  "ComicNeue8.vlw","ComicNeue10.vlw","ComicNeue12.vlw",
  "ComicNeue14.vlw","ComicNeue16.vlw","ComicNeue18.vlw",
  "ComicNeue20.vlw","Cream12.vlw","Cream14.vlw","Cream16.vlw",
  "Cream18.vlw","Cream20.vlw","Densia12.vlw","Densia14.vlw",
  "Densia16.vlw","Densia18.vlw","Densia20.vlw","Dongon12.vlw",
  "Dongon14.vlw","Dongon16.vlw","Dongon18.vlw","Dongon20.vlw",
  "Dongon22.vlw","Ghoust Outline12.vlw","Ghoust Outline14.vlw",
  "Ghoust Outline16.vlw","Ghoust Outline18.vlw",
  "Ghoust Outline20.vlw","Ghoust12.vlw","Ghoust14.vlw",
  "Ghoust16.vlw","Ghoust18.vlw","Ghoust20.vlw",
  "LearningCurve14.vlw","LearningCurve16.vlw",
  "LearningCurve18.vlw","LearningCurve20.vlw",
  "Oups14.vlw","Oups16.vlw","Oups18.vlw","Oups20.vlw",
  "OupsOutline12.vlw","OupsOutline14.vlw","OupsOutline16.vlw",
  "OupsOutline18.vlw","OupsOutline20.vlw","Plank30.vlw",
  "Plank40.vlw","Plank45.vlw","Plank50.vlw","Quicksand.vlw",
  "Quicksand6.vlw","Quicksand8.vlw","Quicksand10.vlw",
  "Quicksand12.vlw","Quicksand14.vlw","Quicksand16.vlw",
  "Quicksand18.vlw","Quicksand20.vlw","QuicksandB.vlw",
  "QuicksandB10.vlw","QuicksandB12.vlw","QuicksandB14.vlw",
  "QuicksandB16.vlw","QuicksandB18.vlw","QuicksandB20.vlw",
  "Rang12.vlw","Rang14.vlw","Rang16.vlw","Rang18.vlw",
  "Rang20.vlw","Rang22.vlw","Roboto-Condensed6.vlw",
  "Roboto-Condensed8.vlw","Roboto-Condensed10.vlw",
  "Roboto-Condensed12.vlw","Roboto-Condensed14.vlw",
  "Roboto-Condensed16.vlw","Roboto-Condensed18.vlw",
  "Roboto-Condensed20.vlw","Roboto-Condensed22.vlw",
  "Roboto-Light6.vlw","Roboto-Light8.vlw","Roboto-Light10.vlw",
  "Roboto-Light12.vlw","Roboto-Light14.vlw","Roboto-Light16.vlw",
  "Roboto-Light18.vlw","Roboto-Light20.vlw","Roboto-Light22.vlw",
  "Smiley12.vlw","Smiley16.vlw","Smiley20.vlw","Smiley24.vlw",
  "Smiley28.vlw","Smiley32.vlw","Smiley36.vlw","Smiley40.vlw",
  "Smiley44.vlw","Smiley48.vlw","Smiley52.vlw","Smiley56.vlw",
  "SuperSquad6.vlw","SuperSquad8.vlw","SuperSquad10.vlw",
  "SuperSquad12.vlw","SuperSquad14.vlw","SuperSquad16.vlw",
  "SuperSquad18.vlw","SuperSquad20.vlw"
};

int fontPage = 0;
unsigned long fontsLastTouch = 0;

int fontPageCount() {
  int n = FONT_COUNT / FONTS_PER_PAGE;
  if (FONT_COUNT % FONTS_PER_PAGE) n++;
  return n;
}

String cleanFontTitle(String f) {
  f.replace(".vlw", "");
  return f;
}

void fontsDrawBg() {
  bool ok = false;

  if (startSD()) {
    if (SD.exists(FONT_BG_IMAGE)) {
      TJpgDec.setJpgScale(1);
      TJpgDec.drawSdJpg(0, 0, FONT_BG_IMAGE);
      ok = true;
    }
    stopSDStartTouch();
  }

  if (!ok) {
    tft.fillScreen(tft.color565(238, 228, 200));
  }
}

void fontsDrawSmallText(String txt, int x, int y, uint8_t datum = TL_DATUM) {
  teSetFont(2);
  teDrawString(txt, x, y, TFT_BLACK, TFT_WHITE, datum, 2);
}

void fontsDrawButtonText(String txt, int x, int y) {
  teSetFont(2);
  teDrawString(txt, x, y, TFT_BLACK, TFT_WHITE, MC_DATUM, 2);
}

void fontsDrawOneFont(int index, int y) {
  if (index < 0 || index >= FONT_COUNT) return;

  String file = String(fontList[index]);
  String title = cleanFontTitle(file);

  if (title.length() > 24) {
    title = title.substring(0, 24);
  }

  if (teLoadFont(file)) {
    teDrawString(title, 160, y, TFT_BLACK, TFT_WHITE, MC_DATUM, 2);
    teUnloadFont();
  } else {
    teSetFont(2);
    teDrawString("Erreur : " + file, 160, y, TFT_RED, TFT_WHITE, MC_DATUM, 2);
  }

  stopSDStartTouch();
}

void fontsDrawPage() {
  fontsDrawBg();

  // Triangle retour sans barre noire
  tft.fillTriangle(10, 16, 31, 6, 31, 27, TFT_BLACK);

  fontsDrawSmallText("FONTS", 160, 14, MC_DATUM);
  fontsDrawSmallText(String(fontPage + 1) + "/" + String(fontPageCount()), 305, 14, TR_DATUM);

  int first = fontPage * FONTS_PER_PAGE;

  fontsDrawOneFont(first + 0, 54);
  fontsDrawOneFont(first + 1, 86);
  fontsDrawOneFont(first + 2, 118);
  fontsDrawOneFont(first + 3, 150);
  fontsDrawOneFont(first + 4, 182);

  // Navigation basse sans barre noire
  fontsDrawButtonText("<", 26, 226);
  fontsDrawButtonText(">", 74, 226);
  fontsDrawButtonText("Menu", 285, 226);
}

void fontsBackToMenu() {
  teUnloadFont();
  stopSDStartTouch();
  drawSubMenu(currentMenu);
}

void launchFonts() {
  appMode = MODE_FONTS;

  stopSDStartTouch();

  fontPage = 0;
  fontsDrawPage();

  Serial.println("APP FONTS LISTE PRETE");
}

void updateFonts() {
  int x, y;

  if (!getTouch(x, y)) return;
  if (millis() - fontsLastTouch < 180) return;

  fontsLastTouch = millis();

  // Retour triangle haut gauche
  if (x >= 0 && x <= 45 && y >= 0 && y <= 36) {
    fontsBackToMenu();
  }

  // Page précédente
  else if (x >= 0 && x <= 50 && y >= 210 && y <= 240) {
    fontPage--;
    if (fontPage < 0) fontPage = fontPageCount() - 1;
    fontsDrawPage();
  }

  // Page suivante
  else if (x >= 55 && x <= 105 && y >= 210 && y <= 240) {
    fontPage++;
    if (fontPage >= fontPageCount()) fontPage = 0;
    fontsDrawPage();
  }

  // Menu
  else if (x >= 245 && x <= 320 && y >= 210 && y <= 240) {
    fontsBackToMenu();
  }

  while (ts.touched()) delay(5);
  delay(80);
}