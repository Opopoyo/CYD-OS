#include "pacman.h"
#include "menu_core.h"

#define PAC_COLS 16
#define PAC_ROWS 11
#define PAC_TILE 18
#define PAC_X0 16
#define PAC_Y0 36

#define PAC_STEP_MS 230
#define PAC_SWIPE_MIN 18
#define PAC_POWER_TIME 55

const char* pacMaze[PAC_ROWS] = {
  "################",
  "#o....#..#....o#",
  "#.##.#....#.##.#",
  "#..............#",
  "###.#.####.#.###",
  " .............. ",
  "###.#.####.#.###",
  "#..............#",
  "#.##.#....#.##.#",
  "#o....#..#....o#",
  "#######..#######"
};

bool pacDots[PAC_ROWS][PAC_COLS];

int pacCol, pacRow;
int pacOldCol, pacOldRow;
int pacScore, pacOldScore;
int pacLives, pacOldLives;
int pacDotsLeft, pacMouth;
int pacPower = 0;

PacDir pacDir = PAC_RIGHT;
PacDir pacNextDir = PAC_RIGHT;

Ghost ghosts[3];
Ghost oldGhosts[3];

unsigned long pacLastStep = 0;

bool pacGameOver = false;
bool pacWin = false;

bool pacTouching = false;
int pacTouchStartX = 0;
int pacTouchStartY = 0;

// =====================================================
// OUTILS
// =====================================================

void pacWrap(int &c, int &r) {
  if (r == 5 && c < 0) c = PAC_COLS - 1;
  else if (r == 5 && c >= PAC_COLS) c = 0;

  if ((c == 7 || c == 8) && r < 0) r = PAC_ROWS - 1;
  else if ((c == 7 || c == 8) && r >= PAC_ROWS) r = 0;
}

bool pacWall(int c, int r) {
  if (c < 0 || c >= PAC_COLS || r < 0 || r >= PAC_ROWS) return false;
  return pacMaze[r][c] == '#';
}

bool pacCanMove(int c, int r, PacDir d) {
  if (d == PAC_UP) r--;
  if (d == PAC_DOWN) r++;
  if (d == PAC_LEFT) c--;
  if (d == PAC_RIGHT) c++;

  pacWrap(c, r);

  if (c < 0 || c >= PAC_COLS || r < 0 || r >= PAC_ROWS) return false;
  return !pacWall(c, r);
}

int pacPX(int c) {
  return PAC_X0 + c * PAC_TILE + PAC_TILE / 2;
}

int pacPY(int r) {
  return PAC_Y0 + r * PAC_TILE + PAC_TILE / 2;
}

void pacMoveEntity(int &c, int &r, PacDir d) {
  if (d == PAC_UP) r--;
  if (d == PAC_DOWN) r++;
  if (d == PAC_LEFT) c--;
  if (d == PAC_RIGHT) c++;
  pacWrap(c, r);
}

PacDir pacOpposite(PacDir d) {
  if (d == PAC_UP) return PAC_DOWN;
  if (d == PAC_DOWN) return PAC_UP;
  if (d == PAC_LEFT) return PAC_RIGHT;
  if (d == PAC_RIGHT) return PAC_LEFT;
  return PAC_STOP;
}

// =====================================================
// DESSIN
// =====================================================

uint16_t pacWallColor(int c, int r) {
  if ((c + r) % 3 == 0) return tft.color565(35, 50, 220);
  if ((c + r) % 3 == 1) return tft.color565(75, 35, 190);
  return tft.color565(110, 45, 180);
}

void pacDrawHeaderFull() {
  tft.fillRect(0, 0, 320, 32, TFT_BLACK);
  tft.fillTriangle(10, 16, 30, 6, 30, 27, TFT_YELLOW);

  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(TFT_YELLOW, TFT_BLACK);
  tft.drawString("PAC-MAN", 160, 9, 2);

  pacOldScore = -1;
  pacOldLives = -1;
}

void pacUpdateHeaderValues() {
  if (pacScore == pacOldScore && pacLives == pacOldLives) return;

  tft.fillRect(45, 20, 230, 12, TFT_BLACK);

  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("Score " + String(pacScore), 82, 25, 1);
  tft.drawString("Vies " + String(pacLives), 236, 25, 1);

  pacOldScore = pacScore;
  pacOldLives = pacLives;
}

void pacDrawTile(int c, int r) {
  if (c < 0 || c >= PAC_COLS || r < 0 || r >= PAC_ROWS) return;

  int x = PAC_X0 + c * PAC_TILE;
  int y = PAC_Y0 + r * PAC_TILE;
  char ch = pacMaze[r][c];

  tft.fillRect(x, y, PAC_TILE, PAC_TILE, TFT_BLACK);

  if (ch == '#') {
    uint16_t col = pacWallColor(c, r);
    tft.fillRoundRect(x + 1, y + 1, PAC_TILE - 2, PAC_TILE - 2, 4, col);
    tft.drawRoundRect(x + 1, y + 1, PAC_TILE - 2, PAC_TILE - 2, 4, tft.color565(80, 170, 255));
    tft.drawRoundRect(x + 3, y + 3, PAC_TILE - 6, PAC_TILE - 6, 3, tft.color565(170, 120, 255));
  } else if (pacDots[r][c]) {
    if (ch == 'o') {
      tft.fillCircle(x + PAC_TILE / 2, y + PAC_TILE / 2, 4, TFT_WHITE);
    } else {
      tft.fillCircle(x + PAC_TILE / 2, y + PAC_TILE / 2, 2, TFT_WHITE);
    }
  }
}

void pacDrawMaze() {
  for (int r = 0; r < PAC_ROWS; r++) {
    for (int c = 0; c < PAC_COLS; c++) {
      pacDrawTile(c, r);
    }
  }
}

void pacDrawPacman() {
  int x = pacPX(pacCol);
  int y = pacPY(pacRow);

  tft.fillCircle(x, y, 8, TFT_YELLOW);

  int open = pacMouth ? 8 : 3;

  if (pacDir == PAC_RIGHT) {
    tft.fillTriangle(x, y, x + 10, y - open, x + 10, y + open, TFT_BLACK);
  } else if (pacDir == PAC_LEFT) {
    tft.fillTriangle(x, y, x - 10, y - open, x - 10, y + open, TFT_BLACK);
  } else if (pacDir == PAC_UP) {
    tft.fillTriangle(x, y, x - open, y - 10, x + open, y - 10, TFT_BLACK);
  } else if (pacDir == PAC_DOWN) {
    tft.fillTriangle(x, y, x - open, y + 10, x + open, y + 10, TFT_BLACK);
  }

  tft.fillCircle(x + 2, y - 4, 1, TFT_BLACK);
}

void pacDrawGhost(Ghost &g) {
  int x = pacPX(g.col);
  int y = pacPY(g.row);

  uint16_t body = (pacPower > 0) ? TFT_BLUE : g.color;

  tft.fillRoundRect(x - 8, y - 8, 16, 18, 7, body);
  tft.fillRect(x - 8, y, 16, 10, body);

  tft.fillCircle(x - 5, y + 9, 3, TFT_BLACK);
  tft.fillCircle(x,     y + 9, 3, TFT_BLACK);
  tft.fillCircle(x + 5, y + 9, 3, TFT_BLACK);

  tft.fillCircle(x - 4, y - 2, 3, TFT_WHITE);
  tft.fillCircle(x + 4, y - 2, 3, TFT_WHITE);
  tft.fillCircle(x - 3, y - 2, 1, TFT_BLACK);
  tft.fillCircle(x + 5, y - 2, 1, TFT_BLACK);
}

void pacDrawMessage(String title, uint16_t color) {
  tft.fillRoundRect(45, 82, 230, 70, 10, TFT_BLACK);
  tft.drawRoundRect(45, 82, 230, 70, 10, color);

  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(color, TFT_BLACK);
  tft.drawString(title, 160, 106, 4);

  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("Touchez pour recommencer", 160, 137, 1);
}

void pacDrawFull() {
  tft.fillScreen(TFT_BLACK);
  pacDrawHeaderFull();
  pacUpdateHeaderValues();
  pacDrawMaze();

  for (int i = 0; i < 3; i++) pacDrawGhost(ghosts[i]);
  pacDrawPacman();
}

void pacRedrawMovingParts() {
  pacDrawTile(pacOldCol, pacOldRow);
  pacDrawTile(pacCol, pacRow);

  for (int i = 0; i < 3; i++) {
    pacDrawTile(oldGhosts[i].col, oldGhosts[i].row);
    pacDrawTile(ghosts[i].col, ghosts[i].row);
  }

  for (int i = 0; i < 3; i++) pacDrawGhost(ghosts[i]);
  pacDrawPacman();

  pacUpdateHeaderValues();

  if (pacGameOver) pacDrawMessage("PERDU", TFT_RED);
  if (pacWin) pacDrawMessage("GAGNE !", TFT_GREEN);
}

// =====================================================
// INIT
// =====================================================

void pacResetDots() {
  pacDotsLeft = 0;

  for (int r = 0; r < PAC_ROWS; r++) {
    for (int c = 0; c < PAC_COLS; c++) {
      char ch = pacMaze[r][c];

      if (ch == '.' || ch == 'o') {
        pacDots[r][c] = true;
        pacDotsLeft++;
      } else {
        pacDots[r][c] = false;
      }
    }
  }
}

void pacResetPositions() {
  pacCol = 8;
  pacRow = 5;
  pacOldCol = pacCol;
  pacOldRow = pacRow;

  pacDir = PAC_RIGHT;
  pacNextDir = PAC_RIGHT;

  ghosts[0] = {1, 1, PAC_RIGHT, TFT_RED};
  ghosts[1] = {14, 1, PAC_LEFT, TFT_CYAN};
  ghosts[2] = {14, 9, PAC_LEFT, tft.color565(255, 105, 180)};

  for (int i = 0; i < 3; i++) oldGhosts[i] = ghosts[i];
}

void pacNewGame() {
  pacScore = 0;
  pacLives = 3;
  pacPower = 0;
  pacGameOver = false;
  pacWin = false;

  pacResetDots();
  pacResetPositions();

  pacDrawFull();
}

// =====================================================
// LOGIQUE
// =====================================================

void pacEatDot() {
  if (pacDots[pacRow][pacCol]) {
    pacDots[pacRow][pacCol] = false;
    pacDotsLeft--;

    if (pacMaze[pacRow][pacCol] == 'o') {
      pacScore += 50;
      pacPower = PAC_POWER_TIME;
    } else {
      pacScore += 10;
    }

    if (pacDotsLeft <= 0) pacWin = true;
  }
}

PacDir pacGhostChoose(Ghost &g) {
  PacDir dirs[4] = {PAC_UP, PAC_DOWN, PAC_LEFT, PAC_RIGHT};
  PacDir best = g.dir;
  int bestDist = (pacPower > 0) ? -1 : 9999;

  for (int i = 0; i < 4; i++) {
    PacDir d = dirs[i];

    if (d == pacOpposite(g.dir) && random(0, 4) != 0) continue;
    if (!pacCanMove(g.col, g.row, d)) continue;

    int nc = g.col;
    int nr = g.row;

    pacMoveEntity(nc, nr, d);

    int dist = abs(nc - pacCol) + abs(nr - pacRow);
    dist += random(0, 5);

    if (pacPower > 0) {
      if (dist > bestDist) {
        bestDist = dist;
        best = d;
      }
    } else {
      if (dist < bestDist) {
        bestDist = dist;
        best = d;
      }
    }
  }

  if (!pacCanMove(g.col, g.row, best)) {
    for (int i = 0; i < 4; i++) {
      if (pacCanMove(g.col, g.row, dirs[i])) return dirs[i];
    }
  }

  return best;
}

void pacRespawnGhost(int i) {
  if (i == 0) ghosts[i] = {1, 1, PAC_RIGHT, TFT_RED};
  if (i == 1) ghosts[i] = {14, 1, PAC_LEFT, TFT_CYAN};
  if (i == 2) ghosts[i] = {14, 9, PAC_LEFT, tft.color565(255, 105, 180)};
}

void pacCheckGhostHit() {
  for (int i = 0; i < 3; i++) {
    bool sameCell = (ghosts[i].col == pacCol && ghosts[i].row == pacRow);

    bool crossed =
      oldGhosts[i].col == pacCol &&
      oldGhosts[i].row == pacRow &&
      ghosts[i].col == pacOldCol &&
      ghosts[i].row == pacOldRow;

    if (sameCell || crossed) {
      if (pacPower > 0) {
        pacScore += 200;
        pacRespawnGhost(i);
      } else {
        pacLives--;

        if (pacLives <= 0) {
          pacGameOver = true;
        } else {
          pacResetPositions();
          pacDrawFull();
        }
      }

      return;
    }
  }
}

void pacStep() {
  if (pacGameOver || pacWin) return;

  pacOldCol = pacCol;
  pacOldRow = pacRow;

  for (int i = 0; i < 3; i++) oldGhosts[i] = ghosts[i];

  if (pacPower > 0) pacPower--;

  if (pacCanMove(pacCol, pacRow, pacNextDir)) pacDir = pacNextDir;

  if (pacCanMove(pacCol, pacRow, pacDir)) {
    pacMoveEntity(pacCol, pacRow, pacDir);
  }

  pacEatDot();

  for (int i = 0; i < 3; i++) {
    ghosts[i].dir = pacGhostChoose(ghosts[i]);

    if (pacCanMove(ghosts[i].col, ghosts[i].row, ghosts[i].dir)) {
      pacMoveEntity(ghosts[i].col, ghosts[i].row, ghosts[i].dir);
    }
  }

  pacCheckGhostHit();

  pacMouth = !pacMouth;
  pacRedrawMovingParts();
}

// =====================================================
// TOUCH SWIPE
// =====================================================

void pacSetDirectionFromSwipe(int dx, int dy) {
  if (abs(dx) < PAC_SWIPE_MIN && abs(dy) < PAC_SWIPE_MIN) return;

  if (abs(dx) > abs(dy)) {
    pacNextDir = (dx > 0) ? PAC_RIGHT : PAC_LEFT;
  } else {
    pacNextDir = (dy > 0) ? PAC_DOWN : PAC_UP;
  }
}

void pacHandleTouchSwipe() {
  int x, y;

  if (!getTouch(x, y)) {
    pacTouching = false;
    return;
  }

  if (pacGameOver || pacWin) {
    pacNewGame();

    while (ts.touched()) delay(5);
    return;
  }

  if (!pacTouching) {
    pacTouchStartX = x;
    pacTouchStartY = y;
    pacTouching = true;

    if (x < 45 && y < 34) {
      stopSDStartTouch();
      drawSubMenu(currentMenu);

      while (ts.touched()) delay(5);
      return;
    }
  } else {
    pacSetDirectionFromSwipe(x - pacTouchStartX, y - pacTouchStartY);
  }
}

// =====================================================
// APP
// =====================================================

void launchPacman() {
  appMode = MODE_PACMAN;

  randomSeed(millis());
  stopSDStartTouch();

  pacTouching = false;
  pacLastStep = millis();

  pacNewGame();

  Serial.println("PAC-MAN CYD OPTIMISE PRET");
}

void updatePacman() {
  pacHandleTouchSwipe();

  if (millis() - pacLastStep >= PAC_STEP_MS) {
    pacLastStep = millis();
    pacStep();
  }
}