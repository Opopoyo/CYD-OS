#include "biblio.h"
#include "menu_core.h"
#include "wifi_app.h"
#include "text_engine.h"

#define BIBLIO_BG "/systeme/Fparch4.jpg"
#define BIBLIO_HOME_ICON "/systeme/iconeBiblio-43px.jpg"
#define BIBLIO_FONT "Roman18.vlw"

#define BIBLIO_CACHE_DIR "/biblio/cache"
#define BIBLIO_BOOKMARK_DIR "/biblio/bookmarks"

#define BIBLIO_FONT_INTERNAL 2
#define BIBLIO_PAGE_CHARS 520

#define BIBLIO_MAX_LOCAL_BOOKS 30
#define BIBLIO_LOCAL_PER_PAGE 6

extern String biblioResults[];
extern String biblioResultIds[];
extern int biblioResultCount;

bool biblioSearchGutenberg(String query);
bool biblioDownloadGutenbergBook(String id, String title, String cachePath);
String biblioCachePathFromId(String id, String title);

enum BiblioState {
  BIBLIO_HOME,
  BIBLIO_KEYBOARD,
  BIBLIO_RESULTS,
  BIBLIO_LIBRARY,
  BIBLIO_READER,
  BIBLIO_ERROR
};

BiblioState biblioState = BIBLIO_HOME;

String biblioQuery = "";
String biblioTitle = "";
String biblioBookId = "";
String biblioFilePath = "";

String localBookNames[BIBLIO_MAX_LOCAL_BOOKS];
String localBookPaths[BIBLIO_MAX_LOCAL_BOOKS];
int localBookCount = 0;
int localBookPage = 0;

int biblioPage = 0;
int biblioPageCountValue = 1;

unsigned long biblioLastTouch = 0;

// =====================================================
// OUTILS
// =====================================================

String biblioBaseName(String path) {
  int slash = path.lastIndexOf('/');
  String n = (slash >= 0) ? path.substring(slash + 1) : path;
  n.replace(".txt", "");
  n.replace("_", " ");
  return n;
}

String biblioSafeName(String s) {
  s.replace("/", "_");
  s.replace("\\", "_");
  s.replace(":", "_");
  s.replace("*", "_");
  s.replace("?", "_");
  s.replace("\"", "_");
  s.replace("<", "_");
  s.replace(">", "_");
  s.replace("|", "_");
  if (s.length() > 42) s = s.substring(0, 42);
  return s;
}

String biblioBookmarkPath(String bookPath) {
  return String(BIBLIO_BOOKMARK_DIR) + "/" + biblioSafeName(biblioBaseName(bookPath)) + ".bm";
}

String biblioFixText(String s) {
  s.replace("Ã©", "é");
  s.replace("Ã¨", "è");
  s.replace("Ãª", "ê");
  s.replace("Ã«", "ë");
  s.replace("Ã ", "à");
  s.replace("Ã¢", "â");
  s.replace("Ã§", "ç");
  s.replace("Ã¹", "ù");
  s.replace("Ã»", "û");
  s.replace("Ã®", "î");
  s.replace("Ã¯", "ï");
  s.replace("Ã´", "ô");
  s.replace("Å“", "œ");
  s.replace("â€™", "'");
  s.replace("â€œ", "\"");
  s.replace("â€", "\"");
  s.replace("â€“", "-");
  s.replace("â€”", "-");
  s.replace("Â«", "«");
  s.replace("Â»", "»");
  s.replace("Â", "");
  return s;
}

// =====================================================
// TEXTE STANDARD SANS FOND
// =====================================================

void biblioText(String txt, int x, int y, uint8_t datum = MC_DATUM) {
  tft.setTextDatum(datum);
  tft.setTextColor(TFT_BLACK);
  tft.drawString(teToDisplay(txt), x, y, 2);
}

void biblioTinyText(String txt, int x, int y, uint8_t datum = MC_DATUM) {
  tft.setTextDatum(datum);
  tft.setTextColor(TFT_BLACK);
  tft.drawString(teToDisplay(txt), x, y, 1);
}

// =====================================================
// UI
// =====================================================

void biblioDrawBg() {
  bool ok = false;

  if (startSD()) {
    if (SD.exists(BIBLIO_BG)) {
      TJpgDec.setJpgScale(1);
      TJpgDec.drawSdJpg(0, 0, BIBLIO_BG);
      ok = true;
    }
    stopSDStartTouch();
  }

  if (!ok) {
    tft.fillScreen(tft.color565(238, 228, 200));
  }
}

void biblioDrawHomeIcon() {
  if (startSD()) {
    if (SD.exists(BIBLIO_HOME_ICON)) {
      TJpgDec.setJpgScale(1);
      TJpgDec.drawSdJpg(139, 34, BIBLIO_HOME_ICON);
    }
    stopSDStartTouch();
  }
}

void biblioHeader(String title) {
  tft.fillTriangle(10, 16, 31, 6, 31, 27, TFT_BLACK);

  if (title.length() > 24) title = title.substring(0, 24);
  biblioText(title, 160, 16, MC_DATUM);
}

// Pagination discrète façon menu CYD
void biblioTinyNav() {
  int y = 17;

  if (biblioPage > 0) {
    tft.fillTriangle(265, y, 274, y - 6, 274, y + 6, TFT_BLACK);
  }

  if (biblioPage < biblioPageCountValue - 1) {
    tft.fillTriangle(311, y, 302, y - 6, 302, y + 6, TFT_BLACK);
  }

  biblioTinyText(
    String(biblioPage + 1) + "/" + String(biblioPageCountValue),
    286,
    18,
    MC_DATUM
  );
}

void biblioButton(int x, int y, int w, int h, String txt) {
  uint16_t bg = tft.color565(255, 248, 224);

  tft.fillRoundRect(x, y, w, h, 7, bg);
  tft.drawRoundRect(x, y, w, h, 7, TFT_BLACK);

  teSetFont(2);
  teDrawString(txt, x + w / 2, y + h / 2, TFT_BLACK, bg, MC_DATUM, 2);
}

void biblioBackToMenu() {
  teUnloadFont();
  tft.setCallback(nullptr);
  stopSDStartTouch();
  drawSubMenu(currentMenu);
}

void biblioDrawLoading(String msg) {
  biblioDrawBg();
  biblioHeader("BIBLIO");
  biblioText(msg, 160, 105);
  biblioText("Veuillez patienter...", 160, 130);
}

// =====================================================
// MARQUE-PAGE
// =====================================================

void biblioSaveBookmark() {
  if (biblioFilePath.length() == 0) return;

  if (startSD()) {
    if (!SD.exists("/biblio")) SD.mkdir("/biblio");
    if (!SD.exists(BIBLIO_BOOKMARK_DIR)) SD.mkdir(BIBLIO_BOOKMARK_DIR);

    File f = SD.open(biblioBookmarkPath(biblioFilePath), FILE_WRITE);
    if (f) {
      f.print(biblioPage);
      f.close();
    }

    stopSDStartTouch();
  }
}

int biblioLoadBookmark(String path) {
  int page = 0;

  if (startSD()) {
    File f = SD.open(biblioBookmarkPath(path), FILE_READ);
    if (f) {
      page = f.readString().toInt();
      f.close();
    }
    stopSDStartTouch();
  }

  if (page < 0) page = 0;
  return page;
}

// =====================================================
// LIVRES CACHE
// =====================================================

void biblioScanLocalBooks() {
  localBookCount = 0;

  if (!startSD()) {
    stopSDStartTouch();
    return;
  }

  if (!SD.exists("/biblio")) SD.mkdir("/biblio");
  if (!SD.exists(BIBLIO_CACHE_DIR)) SD.mkdir(BIBLIO_CACHE_DIR);
  if (!SD.exists(BIBLIO_BOOKMARK_DIR)) SD.mkdir(BIBLIO_BOOKMARK_DIR);

  File dir = SD.open(BIBLIO_CACHE_DIR);

  if (!dir || !dir.isDirectory()) {
    if (dir) dir.close();
    stopSDStartTouch();
    return;
  }

  File f = dir.openNextFile();

  while (f && localBookCount < BIBLIO_MAX_LOCAL_BOOKS) {
    if (!f.isDirectory()) {
      String path = String(f.name());

      if (!path.startsWith("/")) {
        path = String(BIBLIO_CACHE_DIR) + "/" + path;
      }

      String lower = path;
      lower.toLowerCase();

      if (lower.endsWith(".txt")) {
        localBookPaths[localBookCount] = path;
        localBookNames[localBookCount] = biblioBaseName(path);
        localBookCount++;
      }
    }

    f.close();
    f = dir.openNextFile();
  }

  dir.close();
  stopSDStartTouch();
}

int biblioLocalPageCount() {
  int n = localBookCount / BIBLIO_LOCAL_PER_PAGE;
  if (localBookCount % BIBLIO_LOCAL_PER_PAGE) n++;
  if (n < 1) n = 1;
  return n;
}

// =====================================================
// PAGINATION TEXTE
// =====================================================

int biblioCountPages() {
  if (!startSD()) {
    stopSDStartTouch();
    return 1;
  }

  File f = SD.open(biblioFilePath, FILE_READ);
  if (!f) {
    stopSDStartTouch();
    return 1;
  }

  uint32_t pos = 0;
  uint32_t pageStart = 0;
  int pages = 1;

  while (f.available()) {
    char c = f.read();
    pos++;

    if (pos - pageStart >= BIBLIO_PAGE_CHARS && (c == ' ' || c == '\n')) {
      pages++;
      pageStart = pos;
    }

    delay(0);
  }

  f.close();
  stopSDStartTouch();

  if (pages < 1) pages = 1;
  return pages;
}

uint32_t biblioFindPageOffset(int pageWanted) {
  if (pageWanted <= 0) return 0;

  if (!startSD()) {
    stopSDStartTouch();
    return 0;
  }

  File f = SD.open(biblioFilePath, FILE_READ);
  if (!f) {
    stopSDStartTouch();
    return 0;
  }

  uint32_t pos = 0;
  uint32_t pageStart = 0;
  int page = 0;
  uint32_t result = 0;

  while (f.available()) {
    char c = f.read();
    pos++;

    if (pos - pageStart >= BIBLIO_PAGE_CHARS && (c == ' ' || c == '\n')) {
      page++;
      pageStart = pos;

      if (page == pageWanted) {
        result = pos;
        break;
      }
    }

    delay(0);
  }

  f.close();
  stopSDStartTouch();

  return result;
}

String biblioReadPage() {
  String out = "";

  uint32_t start = biblioFindPageOffset(biblioPage);
  uint32_t endPos = biblioFindPageOffset(biblioPage + 1);

  if (!startSD()) {
    stopSDStartTouch();
    return "Erreur SD.";
  }

  File f = SD.open(biblioFilePath, FILE_READ);
  if (!f) {
    stopSDStartTouch();
    return "Fichier introuvable.";
  }

  if (endPos == 0 || endPos <= start) {
    endPos = f.size();
  }

  f.seek(start);

  while (f.available() && f.position() < endPos) {
    out += (char)f.read();
    if (out.length() > BIBLIO_PAGE_CHARS + 80) break;
  }

  f.close();
  stopSDStartTouch();

  return biblioFixText(out);
}

// =====================================================
// AFFICHAGE TEXTE LISEUSE QUICK16
// =====================================================

void biblioDrawWrapped(String s, int x, int y, int maxW, int maxY, int lineH) {
  bool loaded = teLoadFont(BIBLIO_FONT);

  tft.setTextDatum(TL_DATUM);
  tft.setTextColor(TFT_BLACK);

  String word = "";
  String line = "";
  int cy = y;

  for (int i = 0; i <= s.length(); i++) {
    char c = (i < s.length()) ? s[i] : ' ';

    if (c == '\n' || c == ' ') {
      String test = line;
      if (test.length() > 0) test += " ";
      test += word;

      int tw = loaded ? tft.textWidth(test) : tft.textWidth(teToDisplay(test), BIBLIO_FONT_INTERNAL);

      if (tw > maxW && line.length() > 0) {
        if (loaded) tft.drawString(line, x, cy);
        else tft.drawString(teToDisplay(line), x, cy, BIBLIO_FONT_INTERNAL);

        cy += lineH;
        if (cy > maxY) break;

        line = word;
      } else {
        line = test;
      }

      word = "";

      if (c == '\n') {
        if (line.length() > 0) {
          if (loaded) tft.drawString(line, x, cy);
          else tft.drawString(teToDisplay(line), x, cy, BIBLIO_FONT_INTERNAL);
          cy += lineH;
        }

        line = "";

        if (cy > maxY) break;
      }
    } else {
      word += c;
    }
  }

  if (line.length() > 0 && cy <= maxY) {
    if (loaded) tft.drawString(line, x, cy);
    else tft.drawString(teToDisplay(line), x, cy, BIBLIO_FONT_INTERNAL);
  }

  if (loaded) teUnloadFont();
  stopSDStartTouch();
}

// =====================================================
// ECRANS
// =====================================================

void biblioDrawHome() {
  biblioState = BIBLIO_HOME;

  biblioDrawBg();
  biblioHeader("BIBLIO");
  biblioDrawHomeIcon();

  biblioText("Project Gutenberg", 160, 84);

  String q = biblioQuery;
  if (q.length() == 0) q = "Rechercher un livre";
  if (q.length() > 30) q = q.substring(0, 30);

  tft.drawRoundRect(16, 104, 288, 30, 8, TFT_BLACK);
  biblioText(q, 160, 119);

  biblioButton(12, 150, 96, 32, "Recherche");
  biblioButton(112, 150, 96, 32, "Livres SD");
  biblioButton(212, 150, 96, 32, "OK");
}

void biblioDrawResults() {
  biblioState = BIBLIO_RESULTS;

  biblioDrawBg();
  biblioHeader("RESULTATS");

  if (biblioResultCount <= 0) {
    biblioText("Aucun resultat", 160, 92);
    biblioButton(95, 150, 130, 28, "Retour");
    return;
  }

  for (int i = 0; i < biblioResultCount; i++) {
    int y = 44 + i * 29;

    tft.drawRoundRect(12, y, 296, 24, 6, TFT_BLACK);

    String r = biblioResults[i];
    if (r.length() > 31) r = r.substring(0, 31);

    biblioText(String(i + 1) + ". " + r, 160, y + 12);
  }

  biblioButton(98, 216, 124, 20, "Retour");
}

void biblioDrawLibrary() {
  biblioState = BIBLIO_LIBRARY;

  biblioDrawBg();
  biblioHeader("LIVRES SD");

  biblioScanLocalBooks();

  if (localBookCount <= 0) {
    biblioText("Aucun livre en cache", 160, 100);
    biblioText("/biblio/cache/", 160, 125);
    return;
  }

  int first = localBookPage * BIBLIO_LOCAL_PER_PAGE;
  int last = first + BIBLIO_LOCAL_PER_PAGE;
  if (last > localBookCount) last = localBookCount;

  int visible = 0;

  for (int i = first; i < last; i++) {
    int y = 42 + visible * 28;

    tft.drawRoundRect(12, y, 296, 24, 6, TFT_BLACK);

    String n = localBookNames[i];
    if (n.length() > 30) n = n.substring(0, 30);

    int mark = biblioLoadBookmark(localBookPaths[i]);

    biblioText(String(i + 1) + ". " + n, 156, y + 9);

    if (mark > 0) {
      biblioTinyText("p." + String(mark + 1), 286, y + 9);
    }

    visible++;
  }

  int pages = biblioLocalPageCount();

  if (localBookPage > 0) {
    tft.fillTriangle(265, 224, 274, 218, 274, 230, TFT_BLACK);
  }

  if (localBookPage < pages - 1) {
    tft.fillTriangle(311, 224, 302, 218, 302, 230, TFT_BLACK);
  }

  biblioTinyText(String(localBookPage + 1) + "/" + String(pages), 286, 224);
}

void biblioDrawReader() {
  biblioState = BIBLIO_READER;

  biblioDrawBg();
  biblioHeader(biblioTitle);
  biblioTinyNav();

  biblioDrawWrapped(
    biblioReadPage(),
    12,
    38,
    296,
    228,
    20
  );
}

void biblioDrawError(String msg) {
  biblioState = BIBLIO_ERROR;

  biblioDrawBg();
  biblioHeader("ERREUR");

  biblioText(msg, 160, 95);
  biblioText("Essaie un autre resultat.", 160, 122);

  biblioButton(95, 160, 130, 28, "Retour");
}

// =====================================================
// ACTIONS
// =====================================================

void biblioStartSearch() {
  if (WiFi.status() != WL_CONNECTED) {
    launchWifiApp();
    return;
  }

  biblioQuery.trim();
  if (biblioQuery.length() == 0) {
    biblioQuery = "Vingt mille lieues sous les mers";
  }

  biblioDrawLoading("Recherche Gutenberg...");

  bool ok = biblioSearchGutenberg(biblioQuery);

  if (!ok) biblioResultCount = 0;

  biblioDrawResults();
}

void biblioOpenCachedBook(String path, String title) {
  biblioFilePath = path;
  biblioTitle = title;
  biblioBookId = "";
  biblioPageCountValue = biblioCountPages();

  if (biblioPageCountValue < 1) biblioPageCountValue = 1;

  biblioPage = biblioLoadBookmark(path);

  if (biblioPage >= biblioPageCountValue) {
    biblioPage = biblioPageCountValue - 1;
  }

  biblioDrawReader();
}

void biblioOpenBook(String id, String title) {
  if (WiFi.status() != WL_CONNECTED) {
    launchWifiApp();
    return;
  }

  biblioBookId = id;
  biblioTitle = title;
  biblioFilePath = biblioCachePathFromId(id, title);
  biblioPage = 0;

  biblioDrawLoading("Telechargement complet...");

  bool exists = false;

  if (startSD()) {
    exists = SD.exists(biblioFilePath);
    stopSDStartTouch();
  }

  bool ok = exists;

  if (!exists) {
    ok = biblioDownloadGutenbergBook(id, title, biblioFilePath);
  }

  if (!ok) {
    biblioDrawError("Livre non recupere");
    return;
  }

  biblioDrawLoading("Preparation pages...");

  biblioPageCountValue = biblioCountPages();
  if (biblioPageCountValue < 1) biblioPageCountValue = 1;

  biblioPage = biblioLoadBookmark(biblioFilePath);
  if (biblioPage >= biblioPageCountValue) biblioPage = 0;

  biblioDrawReader();
}

// =====================================================
// LANCEMENT / UPDATE
// =====================================================

void launchBiblio() {
  appMode = MODE_BIBLIO;

  stopSDStartTouch();
  WiFi.setSleep(false);
  tft.setCallback(nullptr);

  biblioQuery = "";
  biblioTitle = "";
  biblioBookId = "";
  biblioFilePath = "";
  biblioResultCount = 0;
  biblioPageCountValue = 1;
  biblioPage = 0;
  localBookPage = 0;

  biblioDrawHome();

  Serial.println("BIBLIO PRETE");
}

void updateBiblio() {
  if (biblioState == BIBLIO_KEYBOARD) {
    teKeyboardUpdate();

    if (teKeyboardDone) {
      biblioQuery = teKeyboardValue;
      teKeyboardClose();
      biblioDrawHome();
    }

    if (teKeyboardCancel) {
      teKeyboardClose();
      biblioDrawHome();
    }

    return;
  }

  int x, y;

  if (!getTouch(x, y)) return;
  if (millis() - biblioLastTouch < 180) return;

  biblioLastTouch = millis();

  if (x >= 0 && x <= 45 && y >= 0 && y <= 36) {
    if (biblioState == BIBLIO_READER) {
      biblioSaveBookmark();
      biblioDrawHome();
    } else {
      biblioBackToMenu();
    }

    while (ts.touched()) delay(5);
    delay(80);
    return;
  }

  if (biblioState == BIBLIO_HOME) {
    if (x >= 12 && x <= 108 && y >= 150 && y <= 182) {
      biblioState = BIBLIO_KEYBOARD;
      teKeyboardOpen("Recherche", biblioQuery);
    }

    else if (x >= 112 && x <= 208 && y >= 150 && y <= 182) {
      localBookPage = 0;
      biblioDrawLibrary();
    }

    else if (x >= 212 && x <= 308 && y >= 150 && y <= 182) {
      biblioStartSearch();
    }
  }

  else if (biblioState == BIBLIO_RESULTS) {
    for (int i = 0; i < biblioResultCount; i++) {
      int by = 44 + i * 29;

      if (x >= 12 && x <= 308 && y >= by && y <= by + 24) {
        biblioOpenBook(biblioResultIds[i], biblioResults[i]);
        break;
      }
    }

    if (x >= 98 && x <= 222 && y >= 216 && y <= 236) {
      biblioDrawHome();
    }
  }

  else if (biblioState == BIBLIO_LIBRARY) {
    int first = localBookPage * BIBLIO_LOCAL_PER_PAGE;

    for (int v = 0; v < BIBLIO_LOCAL_PER_PAGE; v++) {
      int index = first + v;
      if (index >= localBookCount) break;

      int by = 42 + v * 28;

      if (x >= 12 && x <= 308 && y >= by && y <= by + 24) {
        biblioOpenCachedBook(localBookPaths[index], localBookNames[index]);
        break;
      }
    }

    if (x >= 256 && x <= 284 && y >= 210 && y <= 240 && localBookPage > 0) {
      localBookPage--;
      biblioDrawLibrary();
    }

    else if (x >= 292 && x <= 320 && y >= 210 && y <= 240 && localBookPage < biblioLocalPageCount() - 1) {
      localBookPage++;
      biblioDrawLibrary();
    }
  }

  else if (biblioState == BIBLIO_READER) {
    if (x >= 256 && x <= 284 && y >= 2 && y <= 34) {
      biblioPage--;
      if (biblioPage < 0) biblioPage = 0;

      biblioSaveBookmark();
      biblioDrawReader();
    }

    else if (x >= 292 && x <= 320 && y >= 2 && y <= 34) {
      biblioPage++;

      if (biblioPage >= biblioPageCountValue) {
        biblioPage = biblioPageCountValue - 1;
      }

      biblioSaveBookmark();
      biblioDrawReader();
    }
  }

  else if (biblioState == BIBLIO_ERROR) {
    if (x >= 95 && x <= 225 && y >= 160 && y <= 188) {
      biblioDrawHome();
    }
  }

  while (ts.touched()) delay(5);
  delay(80);
}