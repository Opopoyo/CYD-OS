#include "sd_web.h"
#include "menu_core.h"
#include "wifi_app.h"

#include <WiFi.h>
#include <WebServer.h>

#define WEBSD_DIR "/systeme/web/websd"

WebServer sdServer(8080);

File sdUploadFile;
bool sdWebStarted = false;
unsigned long sdWebLastTouch = 0;

String cleanPath(String p) {
  p.trim();
  if (p.length() == 0) p = "/";
  if (!p.startsWith("/")) p = "/" + p;
  while (p.indexOf("//") >= 0) p.replace("//", "/");
  if (p.indexOf("..") >= 0) return "/";
  return p;
}

String parentPath(String p) {
  p = cleanPath(p);
  if (p == "/") return "/";
  if (p.endsWith("/")) p.remove(p.length() - 1);
  int slash = p.lastIndexOf('/');
  if (slash <= 0) return "/";
  return p.substring(0, slash);
}

String justName(String p) {
  p = cleanPath(p);
  int slash = p.lastIndexOf('/');
  if (slash < 0) return p;
  return p.substring(slash + 1);
}

String jsonEscape(String s) {
  s.replace("\\", "\\\\");
  s.replace("\"", "\\\"");
  s.replace("\n", "\\n");
  s.replace("\r", "");
  return s;
}

// =====================================================
// FICHIERS WEB SD
// =====================================================

void serveWebFile(String path, String type) {
  if (!startSD()) {
    sdServer.send(500, "text/plain", "Erreur SD");
    stopSDStartTouch();
    return;
  }

  File f = SD.open(path, FILE_READ);

  if (!f) {
    stopSDStartTouch();
    sdServer.send(404, "text/plain", "Fichier introuvable : " + path);
    return;
  }

  sdServer.streamFile(f, type);
  f.close();
  stopSDStartTouch();
}

void handleWebRoot() {
  serveWebFile(String(WEBSD_DIR) + "/index.html", "text/html");
}

void handleWebCss() {
  serveWebFile(String(WEBSD_DIR) + "/style.css", "text/css");
}

void handleWebJs() {
  serveWebFile(String(WEBSD_DIR) + "/script.js", "application/javascript");
}

// =====================================================
// API LISTE JSON
// =====================================================

void handleApiList() {
  String dirPath = "/";
  if (sdServer.hasArg("dir")) dirPath = cleanPath(sdServer.arg("dir"));

  if (!startSD()) {
    sdServer.send(500, "application/json", "{\"ok\":false,\"error\":\"Erreur SD\"}");
    stopSDStartTouch();
    return;
  }

  File dir = SD.open(dirPath);

  if (!dir || !dir.isDirectory()) {
    if (dir) dir.close();
    stopSDStartTouch();
    sdServer.send(404, "application/json", "{\"ok\":false,\"error\":\"Dossier introuvable\"}");
    return;
  }

  sdServer.setContentLength(CONTENT_LENGTH_UNKNOWN);
  sdServer.send(200, "application/json; charset=utf-8", "");

  sdServer.sendContent("{\"ok\":true,\"dir\":\"");
  sdServer.sendContent(jsonEscape(dirPath));
  sdServer.sendContent("\",\"parent\":\"");
  sdServer.sendContent(jsonEscape(parentPath(dirPath)));
  sdServer.sendContent("\",\"items\":[");

  bool firstItem = true;
  File file = dir.openNextFile();

  while (file) {
    String full = String(file.name());

    if (!full.startsWith("/")) {
      if (dirPath == "/") full = "/" + full;
      else full = dirPath + "/" + full;
    }

    if (!firstItem) sdServer.sendContent(",");
    firstItem = false;

    sdServer.sendContent("{\"name\":\"");
    sdServer.sendContent(jsonEscape(justName(full)));
    sdServer.sendContent("\",\"path\":\"");
    sdServer.sendContent(jsonEscape(full));
    sdServer.sendContent("\",\"dir\":");
    sdServer.sendContent(file.isDirectory() ? "true" : "false");
    sdServer.sendContent(",\"size\":");
    sdServer.sendContent(String(file.isDirectory() ? 0 : file.size()));
    sdServer.sendContent("}");

    file.close();
    file = dir.openNextFile();
    delay(1);
  }

  sdServer.sendContent("]}");

  dir.close();
  stopSDStartTouch();
}

// =====================================================
// DOWNLOAD
// =====================================================

void handleDownload() {
  if (!sdServer.hasArg("path")) {
    sdServer.send(400, "text/plain", "Chemin manquant");
    return;
  }

  String path = cleanPath(sdServer.arg("path"));

  if (!startSD()) {
    sdServer.send(500, "text/plain", "Erreur SD");
    stopSDStartTouch();
    return;
  }

  File f = SD.open(path, FILE_READ);

  if (!f || f.isDirectory()) {
    if (f) f.close();
    stopSDStartTouch();
    sdServer.send(404, "text/plain", "Fichier introuvable");
    return;
  }

  sdServer.sendHeader(
    "Content-Disposition",
    "attachment; filename=\"" + justName(path) + "\""
  );

  sdServer.streamFile(f, "application/octet-stream");

  f.close();
  stopSDStartTouch();
}

void handleDownloadAll() {
  sdServer.send(
    200,
    "text/plain",
    "Export complet SD non active.\n"
    "Sur ESP32, un ZIP complet est trop lourd.\n"
    "Utilise le telechargement fichier par fichier."
  );
}

// =====================================================
// UPLOAD
// =====================================================

void handleUploadEnd() {
  String dir = "/";
  if (sdServer.hasArg("dir")) dir = cleanPath(sdServer.arg("dir"));

  sdServer.send(200, "application/json", "{\"ok\":true,\"dir\":\"" + dir + "\"}");
}

void handleUploadData() {
  HTTPUpload& upload = sdServer.upload();

  if (upload.status == UPLOAD_FILE_START) {
    String dir = "/";
    if (sdServer.hasArg("dir")) dir = cleanPath(sdServer.arg("dir"));

    String filename = justName(upload.filename);

    String path = dir;
    if (!path.endsWith("/")) path += "/";
    path += filename;

    if (startSD()) {
      sdUploadFile = SD.open(path, FILE_WRITE);
    }
  }

  else if (upload.status == UPLOAD_FILE_WRITE) {
    if (sdUploadFile) {
      sdUploadFile.write(upload.buf, upload.currentSize);
    }
  }

  else if (upload.status == UPLOAD_FILE_END || upload.status == UPLOAD_FILE_ABORTED) {
    if (sdUploadFile) sdUploadFile.close();
    stopSDStartTouch();
  }
}

// =====================================================
// DELETE / MKDIR
// =====================================================

void handleDelete() {
  if (!sdServer.hasArg("path")) {
    sdServer.send(400, "application/json", "{\"ok\":false,\"error\":\"Chemin manquant\"}");
    return;
  }

  String path = cleanPath(sdServer.arg("path"));

  if (startSD()) {
    File f = SD.open(path);

    if (f) {
      if (f.isDirectory()) SD.rmdir(path);
      else SD.remove(path);
      f.close();
    }

    stopSDStartTouch();
  }

  sdServer.send(200, "application/json", "{\"ok\":true}");
}

void handleMkdir() {
  String dir = "/";
  String name = "";

  if (sdServer.hasArg("dir")) dir = cleanPath(sdServer.arg("dir"));
  if (sdServer.hasArg("name")) name = sdServer.arg("name");

  name.trim();
  name.replace("/", "");
  name.replace("\\", "");

  if (name.length() > 0 && startSD()) {
    String path = dir;
    if (!path.endsWith("/")) path += "/";
    path += name;

    SD.mkdir(path);
    stopSDStartTouch();
  }

  sdServer.send(200, "application/json", "{\"ok\":true}");
}

// =====================================================
// ECRAN CYD
// =====================================================

void drawSdWebScreen() {
  tft.fillScreen(TFT_BLACK);

  tft.fillRect(0, 0, 320, 34, TFT_DARKGREY);
  tft.fillTriangle(10, 17, 31, 6, 31, 28, TFT_WHITE);

  tft.setTextColor(TFT_WHITE, TFT_DARKGREY);
  tft.setTextDatum(MC_DATUM);
  tft.drawString("SDWEB", 160, 17, 2);

  tft.setTextDatum(TL_DATUM);

  if (WiFi.status() == WL_CONNECTED) {
    String url = "http://" + WiFi.localIP().toString() + ":8080/";

    tft.setTextColor(TFT_YELLOW, TFT_BLACK);
    tft.drawString("Depuis ton ordinateur :", 15, 48, 2);

    tft.setTextColor(TFT_CYAN, TFT_BLACK);
    tft.drawString(url, 15, 76, 2);

    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.drawString("HTTP simple uniquement", 15, 108, 2);
    tft.drawString("Pas HTTPS", 15, 130, 2);

    tft.setTextColor(TFT_LIGHTGREY, TFT_BLACK);
    tft.drawString("- telecharger fichiers", 25, 160, 2);
    tft.drawString("- televerser fichiers", 25, 180, 2);
    tft.drawString("- supprimer fichiers", 25, 200, 2);

    tft.setTextColor(TFT_GREEN, TFT_BLACK);
    tft.drawString("Serveur actif", 15, 222, 1);
  } else {
    tft.setTextColor(TFT_RED, TFT_BLACK);
    tft.drawString("WiFi non connecte", 15, 70, 2);
  }
}

// =====================================================
// LANCEMENT / UPDATE
// =====================================================

void launchSdWeb() {
  if (WiFi.status() != WL_CONNECTED) {
    launchWifiApp();
    return;
  }

  appMode = MODE_SD_WEB;

  WiFi.setSleep(false);

  if (sdWebStarted) {
    sdServer.stop();
    sdWebStarted = false;
    delay(100);
  }

  sdServer.on("/", HTTP_GET, handleWebRoot);
  sdServer.on("/style.css", HTTP_GET, handleWebCss);
  sdServer.on("/script.js", HTTP_GET, handleWebJs);

  sdServer.on("/api/list", HTTP_GET, handleApiList);
  sdServer.on("/api/delete", HTTP_GET, handleDelete);
  sdServer.on("/api/mkdir", HTTP_GET, handleMkdir);
  sdServer.on("/api/upload", HTTP_POST, handleUploadEnd, handleUploadData);

  sdServer.on("/download", HTTP_GET, handleDownload);
  sdServer.on("/download_all", HTTP_GET, handleDownloadAll);

  sdServer.begin();
  sdWebStarted = true;

  stopSDStartTouch();
  drawSdWebScreen();

  Serial.print("SDWEB : http://");
  Serial.print(WiFi.localIP());
  Serial.println(":8080/");
}

void updateSdWeb() {
  if (sdWebStarted) {
    sdServer.handleClient();
  }

  int x, y;

  if (!getTouch(x, y)) return;
  if (millis() - sdWebLastTouch < 200) return;

  sdWebLastTouch = millis();

  if (x < 45 && y < 36) {
    sdServer.stop();
    sdWebStarted = false;

    stopSDStartTouch();
    drawSubMenu(currentMenu);

    while (ts.touched()) delay(5);
    delay(80);
  }
}