#include "biblio.h"
#include "menu_core.h"

#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <WiFiClientSecure.h>

#define BIBLIO_CACHE_DIR "/biblio/cache"
#define BIBLIO_MAX_RESULTS 6

String biblioResults[BIBLIO_MAX_RESULTS];
String biblioResultIds[BIBLIO_MAX_RESULTS];
int biblioResultCount = 0;

// =====================================================
// OUTILS
// =====================================================

String biblioUrlEncode(String s) {
  String out = "";
  const char *hex = "0123456789ABCDEF";

  for (int i = 0; i < s.length(); i++) {
    uint8_t c = (uint8_t)s[i];

    if ((c >= 'a' && c <= 'z') ||
        (c >= 'A' && c <= 'Z') ||
        (c >= '0' && c <= '9') ||
        c == '-' || c == '_' || c == '.' || c == '~') {
      out += (char)c;
    } else if (c == ' ') {
      out += '+';
    } else {
      out += "%";
      out += hex[(c >> 4) & 0x0F];
      out += hex[c & 0x0F];
    }
  }

  return out;
}

String biblioSafeFileName(String s) {
  s.toLowerCase();

  s.replace(" ", "_");
  s.replace("/", "_");
  s.replace("\\", "_");
  s.replace(":", "_");
  s.replace("*", "_");
  s.replace("?", "_");
  s.replace("\"", "_");
  s.replace("<", "_");
  s.replace(">", "_");
  s.replace("|", "_");

  while (s.indexOf("__") >= 0) s.replace("__", "_");

  if (s.length() > 42) s = s.substring(0, 42);
  if (s.length() == 0) s = "livre";

  return s + ".txt";
}

String biblioCachePath(String title) {
  return String(BIBLIO_CACHE_DIR) + "/" + biblioSafeFileName(title);
}

String biblioCachePathFromId(String id, String title) {
  return String(BIBLIO_CACHE_DIR) + "/" + id + "_" + biblioSafeFileName(title);
}

String biblioCleanHtmlText(String s) {
  s.replace("&amp;", "&");
  s.replace("&quot;", "\"");
  s.replace("&#39;", "'");
  s.replace("&apos;", "'");
  s.replace("&lt;", "<");
  s.replace("&gt;", ">");
  s.replace("&nbsp;", " ");

  s.replace("\n", " ");
  s.replace("\r", " ");
  s.replace("\t", " ");

  while (s.indexOf("  ") >= 0) s.replace("  ", " ");

  s.trim();
  return s;
}

String biblioExtractBetween(String src, String a, String b, int startIndex) {
  int p1 = src.indexOf(a, startIndex);
  if (p1 < 0) return "";

  p1 += a.length();

  int p2 = src.indexOf(b, p1);
  if (p2 < 0) return "";

  return src.substring(p1, p2);
}

// =====================================================
// RECHERCHE PROJECT GUTENBERG
// =====================================================

bool biblioSearchGutenberg(String query) {
  biblioResultCount = 0;

  if (WiFi.status() != WL_CONNECTED) return false;

  WiFiClientSecure client;
  client.setInsecure();

  HTTPClient http;

  String url = "https://www.gutenberg.org/ebooks/search/?query=" + biblioUrlEncode(query);

  if (!http.begin(client, url)) return false;

  http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
  http.addHeader("User-Agent", "CYD-Biblio/1.0");

  int code = http.GET();

  if (code != 200) {
    Serial.print("GUTENBERG SEARCH HTTP ");
    Serial.println(code);
    http.end();
    return false;
  }

  String html = http.getString();
  http.end();

  int pos = 0;

  while (biblioResultCount < BIBLIO_MAX_RESULTS) {
    int link = html.indexOf("/ebooks/", pos);
    if (link < 0) break;

    int idStart = link + 8;
    int idEnd = idStart;

    while (idEnd < html.length() && isDigit(html[idEnd])) idEnd++;

    if (idEnd <= idStart) {
      pos = link + 8;
      continue;
    }

    String id = html.substring(idStart, idEnd);

    bool already = false;
    for (int i = 0; i < biblioResultCount; i++) {
      if (biblioResultIds[i] == id) already = true;
    }

    String title = biblioExtractBetween(html, "<span class=\"title\">", "</span>", idEnd);

    if (!already && title.length() > 0) {
      title = biblioCleanHtmlText(title);

      biblioResultIds[biblioResultCount] = id;
      biblioResults[biblioResultCount] = title;
      biblioResultCount++;
    }

    pos = idEnd;
  }

  return biblioResultCount > 0;
}

// =====================================================
// TELECHARGEMENT COMPLET TXT
// =====================================================

bool biblioDownloadUrlToFile(String url, String path) {
  WiFiClientSecure client;
  client.setInsecure();

  HTTPClient http;

  Serial.print("GUTENBERG TXT : ");
  Serial.println(url);

  if (!http.begin(client, url)) return false;

  http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
  http.addHeader("User-Agent", "CYD-Biblio/1.0");

  int code = http.GET();

  if (code != 200) {
    Serial.print("HTTP TXT ");
    Serial.println(code);
    http.end();
    return false;
  }

  if (!startSD()) {
    http.end();
    stopSDStartTouch();
    return false;
  }

  if (!SD.exists("/biblio")) SD.mkdir("/biblio");
  if (!SD.exists(BIBLIO_CACHE_DIR)) SD.mkdir(BIBLIO_CACHE_DIR);

  File out = SD.open(path, FILE_WRITE);

  if (!out) {
    http.end();
    stopSDStartTouch();
    return false;
  }

  WiFiClient *stream = http.getStreamPtr();

  uint8_t buffer[512];
  int total = 0;
  unsigned long lastData = millis();

  while (http.connected()) {
    int available = stream->available();

    if (available > 0) {
      int len = stream->readBytes(buffer, min(available, 512));
      out.write(buffer, len);
      total += len;
      lastData = millis();
    } else {
      delay(1);
    }

    if (!stream->connected() && !stream->available()) break;
    if (millis() - lastData > 10000) break;
  }

  out.close();
  http.end();
  stopSDStartTouch();

  Serial.print("GUTENBERG octets : ");
  Serial.println(total);

  return total > 2000;
}

bool biblioDownloadGutenbergBook(String id, String title, String cachePath) {
  if (WiFi.status() != WL_CONNECTED) return false;

  if (startSD()) {
    if (!SD.exists("/biblio")) SD.mkdir("/biblio");
    if (!SD.exists(BIBLIO_CACHE_DIR)) SD.mkdir(BIBLIO_CACHE_DIR);
    if (SD.exists(cachePath)) SD.remove(cachePath);
    stopSDStartTouch();
  }

  String url1 = "https://www.gutenberg.org/cache/epub/" + id + "/pg" + id + ".txt";
  if (biblioDownloadUrlToFile(url1, cachePath)) return true;

  String url2 = "https://www.gutenberg.org/cache/epub/" + id + "/pg" + id + "-0.txt";
  if (biblioDownloadUrlToFile(url2, cachePath)) return true;

  String url3 = "https://www.gutenberg.org/files/" + id + "/" + id + "-0.txt";
  if (biblioDownloadUrlToFile(url3, cachePath)) return true;

  String url4 = "https://www.gutenberg.org/files/" + id + "/" + id + ".txt";
  if (biblioDownloadUrlToFile(url4, cachePath)) return true;

  return false;
}