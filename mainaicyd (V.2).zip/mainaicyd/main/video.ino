#include "video.h"
#include "menu_core.h"
#include "audio_system.h"
#include "audio_wav_player.h"

#define VIDEO_ROOT "/video"

#define VIDEO_MAX_PROJECTS 12
#define VIDEO_PROJECTS_PER_PAGE 6

#define VIDEO_FPS 8
#define VIDEO_FRAME_MS (1000 / VIDEO_FPS)

#define VIDEO_VOLUME 80

// =====================================================
// ETAT
// =====================================================

String videoProjects[VIDEO_MAX_PROJECTS];
int videoProjectCount = 0;
int videoProjectPage = 0;

String videoCurrentProject = "";
String videoCurrentPath = "";

bool videoPlaying = false;
bool videoPaused = false;
bool videoInList = true;

int videoFrame = 0;
int videoFrameCount = 0;

unsigned long videoLastFrame = 0;
unsigned long videoLastTouch = 0;

WavPlayer videoWav;

// =====================================================
// OUTILS SD / PROJETS
// =====================================================

String videoProjectPath(String project) {
  return String(VIDEO_ROOT) + "/" + project;
}

String videoFramePath(int n) {
  char buf[96];
  sprintf(buf, "%s/%04d.jpg", videoCurrentPath.c_str(), n);
  return String(buf);
}

String videoAudioPath() {
  return videoCurrentPath + "/audio.wav";
}

bool videoIsJpg(String name) {
  name.toLowerCase();
  return name.endsWith(".jpg") || name.endsWith(".jpeg");
}

bool videoStartSD() {
  return startSD();
}

void videoCloseSDTouch() {
  stopSDStartTouch();
}

void videoScanProjects() {
  videoProjectCount = 0;

  if (!videoStartSD()) {
    videoCloseSDTouch();
    return;
  }

  if (!SD.exists(VIDEO_ROOT)) {
    SD.mkdir(VIDEO_ROOT);
  }

  File root = SD.open(VIDEO_ROOT);

  if (!root || !root.isDirectory()) {
    if (root) root.close();
    videoCloseSDTouch();
    return;
  }

  File f = root.openNextFile();

  while (f && videoProjectCount < VIDEO_MAX_PROJECTS) {
    if (f.isDirectory()) {
      String name = String(f.name());

      int slash = name.lastIndexOf('/');
      if (slash >= 0) name = name.substring(slash + 1);

      if (name.length() > 0) {
        videoProjects[videoProjectCount] = name;
        videoProjectCount++;
      }
    }

    f.close();
    f = root.openNextFile();
  }

  root.close();
  videoCloseSDTouch();

  if (videoProjectPage < 0) videoProjectPage = 0;

  int pages = (videoProjectCount + VIDEO_PROJECTS_PER_PAGE - 1) / VIDEO_PROJECTS_PER_PAGE;
  if (pages < 1) pages = 1;

  if (videoProjectPage >= pages) videoProjectPage = pages - 1;
}

int videoProjectPageCount() {
  int n = videoProjectCount / VIDEO_PROJECTS_PER_PAGE;
  if (videoProjectCount % VIDEO_PROJECTS_PER_PAGE) n++;
  if (n < 1) n = 1;
  return n;
}

bool videoFrameExists(int n) {
  return SD.exists(videoFramePath(n));
}

int videoCountFrames() {
  int count = 0;

  if (!videoStartSD()) {
    videoCloseSDTouch();
    return 0;
  }

  // Méthode simple et rapide : 0000.jpg, 0001.jpg...
  for (int i = 0; i < 9999; i++) {
    if (SD.exists(videoFramePath(i))) {
      count++;
    } else {
      break;
    }

    delay(1);
  }

  videoCloseSDTouch();
  return count;
}

// =====================================================
// UI
// =====================================================

void videoHeader(String title) {
  tft.fillRect(0, 0, 320, 34, TFT_BLACK);
  tft.fillTriangle(11, 17, 31, 6, 31, 28, TFT_WHITE);

  if (title.length() > 22) title = title.substring(0, 22);

  drawBoldText(title, 160, 17, TFT_WHITE, TFT_BLACK, MC_DATUM, 2);
}

void videoButton(int x, int y, int w, int h, String txt, uint16_t bg) {
  tft.fillRoundRect(x, y, w, h, 7, bg);
  tft.drawRoundRect(x, y, w, h, 7, TFT_WHITE);

  drawBoldText(
    txt,
    x + w / 2,
    y + h / 2,
    TFT_BLACK,
    bg,
    MC_DATUM,
    1
  );
}

void videoDrawTinyPageNav() {
  int total = videoProjectPageCount();
  if (total <= 1) return;

  int y = 17;

  if (videoProjectPage > 0) {
    tft.fillTriangle(265, y, 274, y - 6, 274, y + 6, TFT_WHITE);
  }

  if (videoProjectPage < total - 1) {
    tft.fillTriangle(311, y, 302, y - 6, 302, y + 6, TFT_WHITE);
  }

  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextDatum(MC_DATUM);
  tft.drawString(String(videoProjectPage + 1) + "/" + String(total), 286, 18, 1);
}

void videoDrawProjectList() {
  videoInList = true;
  videoPlaying = false;
  videoPaused = false;

  wavPlayerStop(videoWav);

  tft.fillScreen(TFT_BLACK);
  videoHeader("Videos SD");
  videoDrawTinyPageNav();

  if (videoProjectCount == 0) {
    drawBoldText("Aucun projet", 160, 80, TFT_RED, TFT_BLACK, MC_DATUM, 2);
    drawBoldText("/video/mon_projet/", 160, 110, TFT_WHITE, TFT_BLACK, MC_DATUM, 1);
    drawBoldText("0000.jpg 0001.jpg ...", 160, 130, TFT_LIGHTGREY, TFT_BLACK, MC_DATUM, 1);
    drawBoldText("audio.wav optionnel", 160, 150, TFT_LIGHTGREY, TFT_BLACK, MC_DATUM, 1);

    videoButton(110, 205, 100, 24, "Actualiser", TFT_GREEN);
    return;
  }

  int first = videoProjectPage * VIDEO_PROJECTS_PER_PAGE;
  int last = first + VIDEO_PROJECTS_PER_PAGE;
  if (last > videoProjectCount) last = videoProjectCount;

  int visible = 0;

  for (int i = first; i < last; i++) {
    int x = (visible % 2 == 0) ? 10 : 165;
    int y = 44 + (visible / 2) * 54;

    tft.fillRoundRect(x, y, 145, 46, 8, TFT_WHITE);
    tft.drawRoundRect(x, y, 145, 46, 8, TFT_CYAN);

    String name = videoProjects[i];
    if (name.length() > 15) name = name.substring(0, 15);

    drawBoldText(name, x + 72, y + 18, TFT_BLACK, TFT_WHITE, MC_DATUM, 2);
    drawBoldText("ouvrir", x + 72, y + 34, TFT_DARKGREY, TFT_WHITE, MC_DATUM, 1);

    visible++;
  }

  videoButton(110, 218, 100, 20, "Actualiser", TFT_GREEN);
}

void videoDrawPlayerUI() {
  videoInList = false;

  tft.fillScreen(TFT_BLACK);
  videoHeader(videoCurrentProject);

  tft.drawRect(0, 34, 320, 180, TFT_DARKGREY);

  String info = String(videoFrameCount) + " images - " + String(VIDEO_FPS) + " fps";
  drawBoldText(info, 160, 204, TFT_LIGHTGREY, TFT_BLACK, MC_DATUM, 1);

  String playTxt = "PLAY";
  uint16_t playCol = TFT_GREEN;

  if (videoPlaying && !videoPaused) {
    playTxt = "PAUSE";
    playCol = TFT_ORANGE;
  }

  if (videoPaused) {
    playTxt = "REPLAY";
    playCol = TFT_GREEN;
  }

  videoButton(42, 218, 70, 20, playTxt, playCol);
  videoButton(125, 218, 70, 20, "STOP", TFT_RED);
  videoButton(208, 218, 70, 20, "LISTE", TFT_CYAN);
}

void videoDrawMessage(String a, String b = "") {
  tft.fillRoundRect(35, 86, 250, 70, 10, TFT_BLACK);
  tft.drawRoundRect(35, 86, 250, 70, 10, TFT_CYAN);

  drawBoldText(a, 160, 108, TFT_WHITE, TFT_BLACK, MC_DATUM, 2);

  if (b.length() > 0) {
    drawBoldText(b, 160, 132, TFT_LIGHTGREY, TFT_BLACK, MC_DATUM, 1);
  }
}

// =====================================================
// LECTURE VIDEO
// =====================================================

void videoDrawFrame() {
  if (!videoStartSD()) {
    videoPlaying = false;
    videoDrawMessage("Erreur SD");
    videoCloseSDTouch();
    return;
  }

  String path = videoFramePath(videoFrame);

  if (!SD.exists(path)) {
    videoCloseSDTouch();

    videoPlaying = false;
    videoPaused = false;
    wavPlayerStop(videoWav);

    videoDrawPlayerUI();
    videoDrawMessage("FIN VIDEO", "PLAY pour relancer");
    return;
  }

  // Image plein écran sous la barre du haut.
  // Tes JPG doivent idéalement être en 320x180 ou 320x240.
  // Si elles sont 320x240, le haut sera partiellement couvert par le header.
  TJpgDec.setJpgScale(1);
  TJpgDec.drawSdJpg(0, 34, path.c_str());

  videoFrame++;

  videoCloseSDTouch();
}

void videoStop() {
  videoPlaying = false;
  videoPaused = false;
  videoFrame = 0;

  wavPlayerStop(videoWav);
  videoDrawPlayerUI();
}

void videoPlay() {
  if (videoFrameCount <= 0) {
    videoDrawMessage("Aucune image", "0000.jpg manquant");
    return;
  }

  if (!videoStartSD()) {
    videoDrawMessage("Erreur SD");
    videoCloseSDTouch();
    return;
  }

  videoFrame = 0;
  videoPlaying = true;
  videoPaused = false;
  videoLastFrame = millis();

  String wavPath = videoAudioPath();

  if (SD.exists(wavPath)) {
    wavPlayerOpen(videoWav, wavPath, VIDEO_VOLUME);
  } else {
    Serial.println("VIDEO : audio.wav absent");
  }

  videoCloseSDTouch();

  videoDrawPlayerUI();
  videoDrawFrame();
}

void videoPause() {
  videoPlaying = false;
  videoPaused = true;

  wavPlayerStop(videoWav);

  videoDrawPlayerUI();

  // Réaffiche la dernière frame si possible.
  int last = videoFrame - 1;
  if (last < 0) last = 0;

  if (videoStartSD()) {
    String p = videoFramePath(last);
    if (SD.exists(p)) TJpgDec.drawSdJpg(0, 34, p.c_str());
    videoCloseSDTouch();
  }
}

void videoOpenProject(int index) {
  if (index < 0 || index >= videoProjectCount) return;

  videoCurrentProject = videoProjects[index];
  videoCurrentPath = videoProjectPath(videoCurrentProject);

  tft.fillScreen(TFT_BLACK);
  videoHeader(videoCurrentProject);
  drawBoldText("Analyse du projet...", 160, 110, TFT_WHITE, TFT_BLACK, MC_DATUM, 2);

  videoFrame = 0;
  videoFrameCount = videoCountFrames();

  videoDrawPlayerUI();

  if (videoFrameCount <= 0) {
    videoDrawMessage("Aucune image", "Utilise 0000.jpg");
  } else {
    videoDrawMessage("Pret", String(videoFrameCount) + " images");
  }
}

void videoExit() {
  videoPlaying = false;
  videoPaused = false;

  wavPlayerStop(videoWav);

  SD.end();
  delay(10);

  stopSDStartTouch();
  drawSubMenu(currentMenu);
}

// =====================================================
// LANCEMENT
// =====================================================

void launchVideo() {
  appMode = MODE_VIDEO;

  stopSDStartTouch();
  audioSystemStop();

  wavPlayerInit(videoWav);

  videoPlaying = false;
  videoPaused = false;
  videoInList = true;
  videoFrame = 0;
  videoFrameCount = 0;
  videoProjectPage = 0;

  videoScanProjects();
  videoDrawProjectList();

  Serial.println("VIDEO PLAYER PROJETS PRET");
}

// =====================================================
// UPDATE
// =====================================================

void updateVideo() {
  if (videoPlaying) {
    wavPlayerUpdate(videoWav);

    if (millis() - videoLastFrame >= VIDEO_FRAME_MS) {
      videoLastFrame += VIDEO_FRAME_MS;
      videoDrawFrame();
    }
  }

  int x, y;

  if (!getTouch(x, y)) return;
  if (millis() - videoLastTouch < 180) return;

  videoLastTouch = millis();

  // Retour haut gauche
  if (y < 34 && x < 45) {
    if (videoInList) {
      videoExit();
    } else {
      videoStop();
      videoDrawProjectList();
    }

    while (ts.touched()) delay(5);
    delay(80);
    return;
  }

  if (videoInList) {
    // pagination haut droite
    if (x >= 256 && x <= 284 && y >= 2 && y <= 34) {
      videoProjectPage--;
      if (videoProjectPage < 0) videoProjectPage = 0;
      videoDrawProjectList();
    }

    else if (x >= 292 && x <= 320 && y >= 2 && y <= 34) {
      videoProjectPage++;
      if (videoProjectPage >= videoProjectPageCount()) {
        videoProjectPage = videoProjectPageCount() - 1;
      }
      videoDrawProjectList();
    }

    // actualiser
    else if (x >= 110 && x <= 210 && y >= 218 && y <= 238) {
      videoScanProjects();
      videoDrawProjectList();
    }

    // projets visibles
    else {
      int first = videoProjectPage * VIDEO_PROJECTS_PER_PAGE;

      for (int v = 0; v < VIDEO_PROJECTS_PER_PAGE; v++) {
        int index = first + v;
        if (index >= videoProjectCount) break;

        int bx = (v % 2 == 0) ? 10 : 165;
        int by = 44 + (v / 2) * 54;

        if (x >= bx && x <= bx + 145 && y >= by && y <= by + 46) {
          videoOpenProject(index);
          break;
        }
      }
    }
  }

  else {
    // PLAY / PAUSE / REPLAY
    if (x >= 42 && x <= 112 && y >= 218 && y <= 238) {
      if (videoPlaying) {
        videoPause();
      } else {
        videoPlay();
      }
    }

    // STOP
    else if (x >= 125 && x <= 195 && y >= 218 && y <= 238) {
      videoStop();
    }

    // LISTE
    else if (x >= 208 && x <= 278 && y >= 218 && y <= 238) {
      videoStop();
      videoScanProjects();
      videoDrawProjectList();
    }
  }

  while (ts.touched()) delay(5);
  delay(80);
}